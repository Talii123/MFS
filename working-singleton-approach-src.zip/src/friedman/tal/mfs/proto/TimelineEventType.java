package friedman.tal.mfs.proto;

public enum TimelineEventType {
	SURGERY, CHEMOTHERAPY, RADIATION, IMMUNOTHERAPY, TEST 
}
