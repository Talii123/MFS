package test.friedman.tal;

import java.util.List;

import org.apache.http.cookie.Cookie;
import org.apache.http.impl.client.DefaultHttpClient;

public class TestUtils {

	public static void printCookies(DefaultHttpClient httpClient) {
		List<Cookie> cookies = httpClient.getCookieStore().getCookies();
		if (cookies.isEmpty()) {
			RemoteAppEngineTester.LOGGER.info("None");
		} else {
			for (int i = 0; i < cookies.size(); i++) {
				RemoteAppEngineTester.LOGGER.info("- " + cookies.get(i).toString());
			}
		}
	}

}
