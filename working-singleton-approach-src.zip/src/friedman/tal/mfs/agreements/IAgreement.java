package friedman.tal.mfs.agreements;

import java.util.Date;

import friedman.tal.mfs.users.IUserAccount;
import friedman.tal.mfs.users.IUserInfo;

public interface IAgreement {

	public IAgreementForm getAgreementTerms();
	public Date getTimeofAgreement();
	public IUserAccount getAgreer();
	public IUserInfo getAgreerInfo();
}
