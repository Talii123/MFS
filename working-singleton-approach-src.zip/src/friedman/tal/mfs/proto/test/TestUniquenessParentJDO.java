package friedman.tal.mfs.proto.test;

import javax.jdo.annotations.Inheritance;
import javax.jdo.annotations.PersistenceCapable;
import javax.jdo.annotations.Persistent;

@PersistenceCapable
@Inheritance(customStrategy = "complete-table")
public class TestUniquenessParentJDO extends TestUniquenessLongJDO {

	@Persistent
	private TestUniquenessEncStringJDO _child;
	
	
	public TestUniquenessParentJDO(String aName, String aChildName) {
		super(aName);
		
		this._child = new TestUniquenessEncStringJDO(aChildName);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder(super.toString());
		sb.delete(sb.indexOf("}"), sb.length());
		sb.append("\n\t").append("_child = ").append(this._child.toString());
		sb.append("}");
		return sb.toString();
	}
	
}
