package test.friedman.tal.tester;

import java.io.IOException;

import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.Credentials;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.AuthCache;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.client.protocol.ClientContext;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.client.BasicAuthCache;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.BasicHttpContext;
//import org.jboss.resteasy.client.core.executors.ApacheHttpClient4Executor;
import org.jboss.resteasy.client.ClientExecutor;
import org.jboss.resteasy.client.core.executors.ApacheHttpClient4Executor;

public abstract class AbstractGoogleAppEngineConnector implements IGoogleAppEngineConnector {
	
	private HttpHost _targetHost;
	private DefaultHttpClient _httpClient;
	private BasicHttpContext _localContext;
	//private ApacheHttpClient4Executor _executor;

	private UsernamePasswordCredentials _credentials;

	protected AbstractGoogleAppEngineConnector(String targetHostURI) {
		this._targetHost = //new HttpHost("0-7.fibrolamellar.appspot.com"); 
				new HttpHost(targetHostURI);
		this._httpClient = new DefaultHttpClient();
		AuthCache authCache = new BasicAuthCache();
		BasicScheme basicAuth = new BasicScheme();
		authCache.put(this._targetHost, basicAuth);
		this._localContext = new BasicHttpContext();
		this._localContext.setAttribute(ClientContext.AUTH_CACHE, authCache);

		//_executor = new ApacheHttpClient4Executor(_httpClient, _localContext);
	}
	
	
	
	protected HttpResponse executeRequest(HttpRequestBase anHTTPRequest) throws IOException {
		return this._httpClient.execute(this._targetHost, anHTTPRequest, this._localContext);
	}
	
	protected HttpResponse executeRequest(HttpHost aHost, HttpRequestBase anHTTPRequest) throws IOException {
		return this._httpClient.execute(aHost, anHTTPRequest, this._localContext);
	}	
	
	protected DefaultHttpClient getHttpClient() {
		return this._httpClient;
	}
	
	protected HttpHost getTargetHost() {
		return this._targetHost;
	}
	
	protected ClientExecutor getClientExecutor() {
		return new ApacheHttpClient4Executor(this._httpClient, this._localContext);
	}
	
	protected Credentials getCredentials() {
		// UsernamePasswordCredentials is immutable
		return this._credentials;
	}
	
	protected void setCredentials(String aUserName, String aPassword) {
		this._credentials = new UsernamePasswordCredentials(aUserName, aPassword);
	}
	
	protected void clearCredentials() {
		this._credentials = null;
	}	
}
