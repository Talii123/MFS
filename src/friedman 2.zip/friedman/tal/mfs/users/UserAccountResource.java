package friedman.tal.mfs.users;

import java.io.IOException;

import javax.jdo.JDOObjectNotFoundException;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.SecurityContext;

import com.google.appengine.api.users.UserServiceFactory;

import friedman.tal.IView;
import friedman.tal.JSPView;
import friedman.tal.mfs.MyFibroStoryApplication;
import friedman.tal.mfs.agreements.AgreementFormResource;
import friedman.tal.mfs.agreements.AgreementResource;
import friedman.tal.mfs.agreements.IAgreement;
import friedman.tal.mfs.agreements.IAgreementForm;
import friedman.tal.mfs.timelines.ITimeline;
import friedman.tal.mfs.timelines.TimelineResource;
import friedman.tal.resources.IResourceDAOContext;
import friedman.tal.resources.Resource;
import friedman.tal.resources.ResourceDAO;
import friedman.tal.util.StringMaker;
import friedman.tal.util.Utils;


@Path(UserAccountResource.RESOURCE_URL)
public class UserAccountResource extends Resource<IUserAccount> {

	public static final String RESOURCE_URL = "/signup";
	
	public static final String SIGNUP_FORM_AGREEMENT_FORM_PARAM_NAME = "agreementForm";
	public static final String POST_SIGN_UP_FORM_URL_PARAM_NAME = "postSignUpFormURL";
	
	public static final String NEW_TIMELINE_REQUIRED_AGREEMENT_FORM_NAME = "newTLRequiredAgreementFormName";
	public static final String NEW_TIMELINE_REQUIRED_AGREEMENT_FORM_REVISION_NUM = "newTLRequiredAgreementFormRevisionNum";
	
	private static final String SIGNUP_FORM_LIST_URI = "/WEB-INF/SignupForm.jsp";
	
	private static final IView SIGNUP_VIEW = new JSPView(SIGNUP_FORM_LIST_URI);
	
	@Deprecated
	public UserAccountResource() {
	}
	
	public UserAccountResource(IResourceDAOContext aDAOContext) {
		super(aDAOContext);
	}

	
	@GET	
	@Produces("text/html")
	public void getSignupForm(@Context HttpServletRequest request, @Context HttpServletResponse response, @Context ServletContext context) 
			throws IOException, ServletException {
		LOGGER.debug("request: "+StringMaker.requestToString(request));
		LOGGER.debug("user: "+StringMaker.googleUserToString((UserServiceFactory.getUserService().getCurrentUser())));
		MyFibroStoryApplication application = MyFibroStoryApplication.getApplication();
		
		// TODO: cache requiredAgreementForm in the MyFibroStoryApplication object
		final String requiredAgreementFormName = application.getSetting(NEW_TIMELINE_REQUIRED_AGREEMENT_FORM_NAME);
		final String requiredAgreementFormRevisionNum = application.getSetting(NEW_TIMELINE_REQUIRED_AGREEMENT_FORM_REVISION_NUM);
		
		// TODO add support for security context
		AgreementFormResource agreementFormResource = new AgreementFormResource(getDAOContext());
		IAgreementForm requiredAgreementForm = agreementFormResource.getAgreementForm(requiredAgreementFormName, Integer.valueOf(requiredAgreementFormRevisionNum));
				
		request.setAttribute(SIGNUP_FORM_AGREEMENT_FORM_PARAM_NAME, requiredAgreementForm);
		request.setAttribute(POST_SIGN_UP_FORM_URL_PARAM_NAME, RESOURCE_URL);		
		SIGNUP_VIEW.render(request, response);
	}
	
	
	/*
	 * @FormParam("agreementName") String anAgreementFormName, 
								@FormParam("agreementRevision") Integer anAgreementRevisionNum,
								@FormParam("firstName") String aFirstName,
								@FormParam("lastName") String aLastName,
								@FormParam("email") String anEmail,
								@FormParam("timelineID") String aTimelineID,
								
	 */
	@POST
	@Consumes(Utils.HTML_FORM_MEDIATYPE)
	public void signUp(MultivaluedMap<String, String> aSignUpForm) 								
			throws ServletException, IOException {

		UserResourceDAO<? extends IUserAccount> userDAO = getDAO();
		
		try {			
			userDAO.initIfLocalTrxn();
			// trxn 1
			IUserAccount userAccount = userDAO.createUserAccount();
			// passing the userAccount into the context via this method, rather than passing the variable;
			// don't want callers to be able to pass userAccount objects around explicitly (more to the point, don't want mutators that
			// accept UserAccount objects; let the IResourceDAOContext worry about propagating data
			IResourceDAOContext myContext = getDAOContext();
			myContext.addToContext(userDAO);
			
			// myContext should now have the new userAccount cached in it so that is available to anyone using the context even if
			// the database is not completely updated
			
			userDAO.commitIfLocalTrxn();
			
			userDAO.initIfLocalTrxn();
			
			// trxn 2
			AgreementResource agreementResource = new AgreementResource(myContext);
			IAgreement newAgreement = agreementResource.makeAgreement(aSignUpForm.getFirst("agreementName"), Integer.valueOf(aSignUpForm.getFirst("agreementRevision")));
			
			// NOTE: trxn 2 cannot rely on any data created by trxn 1 that is fetched via queries as indexes will likely not yet be up to date;
			// all data required for trxn 2 should be retrieved by key only
			// UserAccounts are retrieved by key only
			// Agreements are OWNED by UserAccounts; since it's a collection I believe it is fetched by a query
			
			// NOTE: if combine into 1 transaction, cannot read data created by the operations of trxn 1 in trxn 2 as GAEJ uses 
			// 'snapshot isolation'; since here we want to require that the appropriate agreement is IN THE DATABASE for the user before
			// he/she can create a timeline, I've opted for 2 separate transactions; if it turns out that the data from trxn 1 is not always
			// available inside transaction 2, will have to settle for combining the transactions and therefore will not be able to read
			// the 'agreements' from the database but rather from the transaction context.
			
			// trxn 2
			//PersistenceManager pm = PMF.getNewPM();
			TimelineResource timelineResource = new TimelineResource(myContext/*, null*/);
			timelineResource.createAndRenderTimeline(aSignUpForm);		
			
			userDAO.commitIfLocalTrxn();
		} finally {
			userDAO.cleanupIfLocalTrxn();
		}		
		
	}


	@Override
	@SuppressWarnings("unchecked")
	protected UserResourceDAO<? extends IUserAccount> getDAO() {
		logContextFields();
		return new UserResourceDAO<UserAccountJDO>(UserAccountJDO.class, getDAOContext());		
	}		
	
	private final class UserResourceDAO<T extends IUserAccount> extends ResourceDAO<T> {
		private UserResourceDAO(Class<T> theDBClass, IResourceDAOContext aDAOContext) {
			super(theDBClass, aDAOContext);
		}
		
		private IUserAccount createUserAccount() {		
			IUserAccount userAccount = null;
			try {
				this.initIfLocalTrxn();
				
				userAccount = getUserAccount();
				// this should throw an exception if the user already exists 
				//throw new IllegalStateException("User account already exists!");
				if (userAccount == null) {
					userAccount = new UserAccountJDO(getDAOContext().getUser().getName());
					this._pm.makePersistent(userAccount);
					this.cacheUserAccount(userAccount);
				}
				
				_logger.debug("commit transaction if it's local;  is local? {}", (this.isLocalTrxn() ? "yes" : "no"));
				this.commitIfLocalTrxn();				
				
			} finally {
				this.cleanupIfLocalTrxn();
			}
			
			return userAccount;
		}
		
		
//		private IUserAccount createUserAccount() {		
//			IUserAccount userAccount = null;
//			try {
//				this.initIfLocalTrxn();
//				
//				userAccount = getUserAccount();
//				// this should throw an exception if the user already exists 
//				//throw new IllegalStateException("User account already exists!");
//			} catch (JDOObjectNotFoundException nfe) {
//				try {
//					userAccount = new UserAccountJDO(getDAOContext().getUser().getName());
//					this._pm.makePersistent(userAccount);
//					
//					_logger.debug("commit transaction if it's local;  is local? {}", (this.isLocalTrxn() ? "yes" : "no"));
//					this.commitIfLocalTrxn();
//				} finally {
//					// do nothing
//				}
//				
//			} finally {
//				this.cleanupIfLocalTrxn();
//			}
//			
//			return userAccount;
//		}


		/*private IUserAccount getUserAccount() {
			this.initIfLocalTrxn();
			
			IUserAccount userAccount = null;
			
			try {
				Principal user = getDAOContext().getUser();				
				String username = user.getName();
				_logger.debug("getting UserAccountJDO for username: '{}' ", username);
				userAccount = this._pm.getObjectById(UserAccountJDO.class, username);
				_logger.debug("retrieved userAccount: '{}' ", userAccount);
				this.commitIfLocalTrxn();
			} /*catch (Exception e) {
				this.exceptionThrown(e);
			} *//*
			finally {
				this.cleanupIfLocalTrxn();
			}

			return userAccount;
		}	*/	
	}

}
