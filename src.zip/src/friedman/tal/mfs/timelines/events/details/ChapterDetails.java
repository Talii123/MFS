package friedman.tal.mfs.timelines.events.details;

import java.util.Map;

import javax.jdo.annotations.EmbeddedOnly;
import javax.jdo.annotations.PersistenceCapable;

import friedman.tal.mfs.timelines.events.EventDetails;
import friedman.tal.mfs.timelines.events.EventType;

@PersistenceCapable
@EmbeddedOnly
public class ChapterDetails extends EventDetails {

	private ChapterDetails() {}
	
	static ChapterDetails fromMap(Map<String, String> aMap) {
		return new ChapterDetails();
	}
	
	public static final EventType getType() {
		return EventType.CHAPTER;
	}

}
