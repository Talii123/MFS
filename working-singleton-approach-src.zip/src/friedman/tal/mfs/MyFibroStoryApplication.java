package friedman.tal.mfs;

import java.util.Set;

import javax.servlet.ServletContext;
import javax.ws.rs.core.Context;

import friedman.tal.BaseApplication;
import friedman.tal.mfs.agreements.AgreementFormResource;
import friedman.tal.mfs.proto.test.TestUniquenessResource;
import friedman.tal.mfs.users.UserResource;
import friedman.tal.util.Utils;

public class MyFibroStoryApplication extends BaseApplication {
	
	private static MyFibroStoryApplication _theApplication;
	
	public static final MyFibroStoryApplication getApplication() {
		if (_theApplication == null) {
			// this really never should happen
			throw new IllegalAccessError("getApplication() called before the application was initialized!");
		}
		
		return _theApplication;
	}
	
	// don't want to use public constructor as part of Singleton pattern, but JAX-RS requires this
	public MyFibroStoryApplication(@Context ServletContext context) {
		super(context);
		
		if (_theApplication == null) {
			synchronized (MyFibroStoryApplication.class) {
				if (_theApplication == null) {
					_theApplication = this;
					
					Set<Object> singletons = Utils.newSet();
					//singletons.add(new AgreementFormResource());			
					singletons.add(new TestUniquenessResource());
					setSingletons(singletons);
					
					Set<Class<?>> perResourceClasses = Utils.newSet();
					perResourceClasses.add(AgreementFormResource.class);
					perResourceClasses.add(UserResource.class);
					setClasses(perResourceClasses);
				}
			}			
		}		
	}
	
}
