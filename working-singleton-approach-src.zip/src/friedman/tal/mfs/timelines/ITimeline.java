package friedman.tal.mfs.timelines;

public interface ITimeline {

}
