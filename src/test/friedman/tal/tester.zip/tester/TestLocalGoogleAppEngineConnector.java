package test.friedman.tal.tester;

import static org.junit.Assert.*;

import org.junit.Test;


public class TestLocalGoogleAppEngineConnector {

	
	private String _username;
	private LocalGoogleAppEngineConnector _connector;
	
	
	public TestLocalGoogleAppEngineConnector() {
		this._username = "Tal"; 
		this._connector = new LocalGoogleAppEngineConnector("");
	}
	
	@Test
	public void testLogInAsAdmin() {
		boolean isLoginSuccessful = this._connector.logInAsAdmin();
		assertTrue("log in successful? ", isLoginSuccessful);
		assertTrue("logged in as admin? ", this._connector.isLoggedInAsAdmin());
	}
	
	@Test
	public void testLogIn() {
		System.out.println(String.format("Trying to login as %s..", this._username));
		boolean isActionSuccessful = this._connector.logInAs(this._username, "no password");
		assertTrue("Login successful? ", isActionSuccessful);
		// since the logInAs() method on the dev server logs users in NOT as admin, this should be false, though it's not strictly necessary  for the live server
		assertFalse("logged in as admin? ", this._connector.isLoggedInAsAdmin());
	}
	
	@Test
	public void testLogOut() {
		if (!this._connector.isLoggedIn()) {
			this._connector.logInAs(this._username, "");
		}
		assertTrue("isLoggedIn?", this._connector.isLoggedIn());
		
		System.out.println("Now attempting to log out.");
		boolean isLogOutSuccessful = this._connector.logOut();
		assertTrue("Log out successful? ", isLogOutSuccessful);
	}

}
