package friedman.tal.mfs.timelines.events.details;

import java.util.Map;

import friedman.tal.mfs.timelines.events.EventDetails;
import friedman.tal.mfs.timelines.events.IEventDetails;
import friedman.tal.mfs.timelines.events.TimeUnit;


public class SurgeryDetails extends EventDetails implements IEventDetails {

	private String _surgeon;
	private String _fellow;
	private String _physicianAssistant;
	private String _hospital;
	private String _location;
	private byte _recoveryTimeHospitalQty;
	private TimeUnit _recoveryTimeHospitalUnit;
	private byte _recoveryTimeHomeQty;
	private TimeUnit _recoveryTimeHomeUnit;	
	
	public static SurgeryDetails fromMap(Map<String, String> aMap) {
		// TODO Auto-generated method stub
		return null;
	}

}
