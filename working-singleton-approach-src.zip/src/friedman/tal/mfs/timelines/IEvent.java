package friedman.tal.mfs.timelines;

import java.util.Date;

public interface IEvent {

	public Date getStart();
	public Date getEnd();
	public String getTitle();
}
