package friedman.tal.mfs.timelines.events;


public interface IEventDetails {
}
