package friedman.tal.mfs.timelines.events.details;

import java.util.Map;

import javax.jdo.annotations.EmbeddedOnly;
import javax.jdo.annotations.PersistenceCapable;

import friedman.tal.mfs.NotSet;
import friedman.tal.mfs.timelines.events.EventDetails;
import friedman.tal.mfs.timelines.events.details.ChemoDetails.Field;
import friedman.tal.util.Utils;

@PersistenceCapable
@EmbeddedOnly
public class ImmunoDetails extends EventDetails {

	
	/*public enum Field {
		
	}*/
	
	private ImmunoDetails(Map<String, String> aMap) {		
		// this check cannot be moved to the super class constructor
		if (aMap == null) return;
		
		String value;
		
		value = Utils.getValueOrEmptyString(aMap.get(Field.oncologist.name()));
		//value = Utils.getValueOrEmptyString(aMap.get("oncologist"));
		
	}
	
	public static ImmunoDetails fromMap(Map<String, String> aMap) {
		return new ImmunoDetails(aMap);
	}
}
