package nolongerused;

interface DefaultInter {

	public void publicMethod();
	void defaultMethod();
}
