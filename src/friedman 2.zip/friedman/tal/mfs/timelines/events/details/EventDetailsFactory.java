package friedman.tal.mfs.timelines.events.details;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import friedman.tal.mfs.timelines.events.EventDetails;
import friedman.tal.mfs.timelines.events.EventType;


public class EventDetailsFactory {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(EventDetailsFactory.class);

	public static EventDetails getAsEventDetails(EventType anEventType, Map<String, String> anEventDetailsMap) {
		LOGGER.debug("anEventType: {} , anEventDetailsMap: {}", anEventType, anEventDetailsMap);
		
		EventDetails details;
		
		switch (anEventType) {
		case CHAPTER:
			details = ChapterDetails.fromMap(anEventDetailsMap);
			break;
			
		case DIAGNOSIS:
			details = DiagnosisDetails.fromMap(anEventDetailsMap);
			break;

		case SURGERY: 
			details = SurgeryDetails.fromMap(anEventDetailsMap);
			break;
			
		case CHEMO:
			details = ChemoDetails.fromMap(anEventDetailsMap);
			break;
			
		case RADIATION:
			details = RadiationDetails.fromMap(anEventDetailsMap);
			break;
			
		case IMMUNO:
			details = ImmunoDetails.fromMap(anEventDetailsMap);
			break;
			
		case TEST:
			details = TestDetails.fromMap(anEventDetailsMap);
			break;
		default:
			LOGGER.error("Unrecognized Event Details type: {}; cannot create an Event Details object.", anEventType);
			throw new IllegalArgumentException(String.format("Unrecognized Event Details type: %s; cannot create an Event Details object.", anEventType));
		}
		
		return details;
	}	
}
