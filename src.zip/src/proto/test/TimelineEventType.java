package proto.test;

public enum TimelineEventType {
	SURGERY, CHEMOTHERAPY, RADIATION, IMMUNOTHERAPY, TEST 
}
