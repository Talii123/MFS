package friedman.tal.mfs;

import java.util.Set;

import javax.servlet.ServletContext;
import javax.ws.rs.core.Context;

import proto.test.TestEmbeddableResource;
import proto.test.TestJDOResource;
import proto.test.TestNullResource;
import proto.test.TestTransactionResource;
import proto.test.TestUniquenessResource;



import friedman.tal.BaseApplication;
import friedman.tal.ConfiguredJacksonProvider;
import friedman.tal.mfs.agreements.AgreementFormResource;
import friedman.tal.mfs.timelines.TimelineResource;
import friedman.tal.mfs.users.UserAccountResource;
import friedman.tal.util.Utils;

public class MyFibroStoryApplication extends BaseApplication {
	
	private static MyFibroStoryApplication _theApplication;
	
	public static final MyFibroStoryApplication getApplication() {
		if (_theApplication == null) {
			// this really never should happen
			throw new IllegalAccessError("getApplication() called before the application was initialized!");
		}
		
		return _theApplication;
	}
	
	// don't want to use public constructor as part of Singleton pattern, but JAX-RS requires this
	public MyFibroStoryApplication(@Context ServletContext context) {
		super(context);
		
		if (_theApplication == null) {
			synchronized (MyFibroStoryApplication.class) {
				if (_theApplication == null) {
					_theApplication = this;
					
					Set<Object> singletons = Utils.newSet();
					//singletons.add(new AgreementFormResource());			
					//singletons.add(new TestUniquenessResource());
					singletons.add(new TestTransactionResource());
					singletons.add(new TestEmbeddableResource());
					singletons.add(new TestJDOResource());
					singletons.add(new TestNullResource());
					singletons.add(new AdminResource());
					
					singletons.add(new ConfiguredJacksonProvider());
					
					setSingletons(singletons);
					
					Set<Class<?>> perResourceClasses = Utils.newSet();
					perResourceClasses.add(AgreementFormResource.class);
					perResourceClasses.add(UserAccountResource.class);
					perResourceClasses.add(TimelineResource.class);
					
					perResourceClasses.add(TestUniquenessResource.class);
					
					setClasses(perResourceClasses);
				}
			}			
		}		
	}
	
}
