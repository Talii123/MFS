package friedman.tal.mfs;

import friedman.tal.mfs.timelines.events.details.CancerStage;

public class NotSet extends friedman.tal.NotSet {

	public static final CancerStage CANCER_STAGE = null;

}
