package friedman.tal.mfs.proto;

public class DefaultInterImpl implements DefaultInter {

	@Override
	public void publicMethod() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void defaultMethod() {
		// TODO Auto-generated method stub
		
	}

}
