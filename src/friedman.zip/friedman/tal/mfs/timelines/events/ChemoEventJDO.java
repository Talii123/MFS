package friedman.tal.mfs.timelines.events;

import javax.jdo.annotations.PersistenceCapable;
import javax.jdo.annotations.Persistent;

import friedman.tal.jdo.TypedKey;
import friedman.tal.mfs.timelines.EventJDO;
import friedman.tal.mfs.timelines.EventTO;
import friedman.tal.mfs.timelines.ITimeline;
import friedman.tal.mfs.timelines.events.details.ChemoDetails;

@PersistenceCapable
public class ChemoEventJDO extends EventJDO {

	@Persistent
	private ChemoDetails _eventDetails;
	
	ChemoEventJDO(EventTO anEventTO, TypedKey<? extends ITimeline, String> aTimelineKey) {
		super(anEventTO, aTimelineKey);
		this._eventDetails = (ChemoDetails)anEventTO.getTypeDetails();
	}
}
