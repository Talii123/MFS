package friedman.tal.mfs.timelines.events.details;

import java.util.Map;

import javax.jdo.annotations.EmbeddedOnly;
import javax.jdo.annotations.PersistenceCapable;
import javax.jdo.annotations.Persistent;

import friedman.tal.mfs.NotSet;
import friedman.tal.mfs.timelines.events.EventDetails;
import friedman.tal.mfs.timelines.events.IEventDetails;
import friedman.tal.util.Utils;

@PersistenceCapable
@EmbeddedOnly
public class SurgeryDetails extends EventDetails implements IEventDetails {
	@Persistent
	private String _surgeon;
	
	@Persistent
	private String _fellow;
	
	@Persistent
	private String _physicianAssistant;
	
	@Persistent
	private String _hospital;
	
	@Persistent
	private String _location;
	/*private byte _recoveryTimeHospitalQty;
	private TimeUnit _recoveryTimeHospitalUnit;
	private byte _recoveryTimeHomeQty;
	private TimeUnit _recoveryTimeHomeUnit;*/
	
	@Persistent
	private String _recoveryTimeHospital;
	
	@Persistent
	private String _recoveryTimeHome;
	
	public enum Field {
		surgeon,
		fellow,
		physicianAssistant,
		hospital,
		location,
		recoveryTimeHospital,
		recoveryTimeHome
	}
	
	
	private SurgeryDetails(Map<String, String> aMap) {		
		// this check cannot be moved to the super class constructor
		if (aMap == null) return;
		
		String value;
		
		value = Utils.getValueOrEmptyString(aMap.get(Field.surgeon.name()));
		this._surgeon = value.length() > 0 ? value : NotSet.STRING;
		
		value = Utils.getValueOrEmptyString(aMap.get(Field.fellow.name()));
		this._fellow = value.length() > 0 ? value : NotSet.STRING;
		
		value = Utils.getValueOrEmptyString(aMap.get(Field.physicianAssistant.name()));
		this._physicianAssistant = value.length() > 0 ? value : NotSet.STRING;
		
		value = Utils.getValueOrEmptyString(aMap.get(Field.hospital.name()));
		this._hospital = value.length() > 0 ? value : NotSet.STRING;
		
		value = Utils.getValueOrEmptyString(aMap.get(Field.location.name()));
		this._location = value.length() > 0 ? value : NotSet.STRING;
		
		value = Utils.getValueOrEmptyString(aMap.get(Field.recoveryTimeHome.name()));
		this._recoveryTimeHome = value.length() > 0 ? value : NotSet.STRING;
		
		value = Utils.getValueOrEmptyString(aMap.get(Field.recoveryTimeHospital.name()));
		this._recoveryTimeHospital = value.length() > 0 ? value : NotSet.STRING;		
	}
	
	static SurgeryDetails fromMap(Map<String, String> aMap) {
		return new SurgeryDetails(aMap); 
	}

}
