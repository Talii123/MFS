package friedman.tal.mfs.timelines.events.details;

import java.util.Map;

import javax.jdo.annotations.EmbeddedOnly;
import javax.jdo.annotations.NotPersistent;
import javax.jdo.annotations.PersistenceCapable;
import javax.jdo.annotations.Persistent;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import friedman.tal.mfs.NotSet;
import friedman.tal.mfs.timelines.events.EventDetails;
import friedman.tal.util.Utils;

@PersistenceCapable
@EmbeddedOnly
public class ChemoDetails extends EventDetails {
	
	@NotPersistent
	private static final Logger LOGGER = LoggerFactory.getLogger(ChemoDetails.class);
	
	@Persistent
	private String _oncologist;
	
	
	public enum Field {
		oncologist;
	}
	
	private ChemoDetails(Map<String, String> aMap) {		
		// this check cannot be moved to the super class constructor
		if (aMap == null) return;
		
		String value;
		
		value = Utils.getValueOrEmptyString(aMap.get(Field.oncologist));
		this._oncologist = value.length() > 0 ? value : NotSet.STRING;
	}
	
	static ChemoDetails fromMap(Map<String, String> aMap) {
		return new ChemoDetails(aMap);
	}

}
