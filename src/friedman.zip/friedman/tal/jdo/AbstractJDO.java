package friedman.tal.jdo;

import javax.jdo.annotations.PersistenceCapable;

import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;

public abstract class AbstractJDO<K> implements IJDO<K> {

	//public abstract T getKey();
	
	/*@Override
	public abstract Key getKey();
	
	@Override
	public abstract Key createKey(T simpleKeyValue);*/


}

