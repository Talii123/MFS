package friedman.tal.mfs.timelines;

import java.util.Date;

import javax.jdo.annotations.PersistenceCapable;
import javax.jdo.annotations.Persistent;

@PersistenceCapable
public class EventJDO implements IEvent {

	@Persistent
	private Date _start;
	
	@Persistent
	private Date _end;
	
	@Persistent
	private String _title;
	
	public EventJDO(Date aStartDate, Date anEndDate, String aTitle) {
		this._start = aStartDate;
		this._end = anEndDate;
		this._title = aTitle;
	}
	
	// for now, use default .equals() method -> events are only equal if it they have the same key
	
	@Override
	public Date getStart() {
		return this._start;
	}

	@Override
	public Date getEnd() {
		return this._end;
	}

	@Override
	public String getTitle() {
		return this._title;
	}

}
