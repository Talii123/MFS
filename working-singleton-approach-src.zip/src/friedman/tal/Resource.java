package friedman.tal;

import javax.jdo.PersistenceManager;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.SecurityContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import friedman.tal.util.PMF;
import friedman.tal.util.StringMaker;

public abstract class Resource<T> {
	
	private final PersistenceManager _pm;
	
	protected final Logger LOGGER = LoggerFactory.getLogger(this.getClass());
	
	@Context
	private SecurityContext _sc;
	
	public Resource() {
		this._pm = null;

		logContextFields();
	}
	
	protected Resource(PersistenceManager aPM, SecurityContext anSC) {
		this._pm = aPM;
		this._sc = anSC;
		
		logContextFields();
	}
	
	protected final SecurityContext getSecurityContext() {
		return this._sc;
	}
	
	protected final PersistenceManager getPM() {
		return this._pm != null ? this._pm : PMF.getNewPM();
	}
	
	
	protected void logContextFields() {
		LOGGER.debug("_pm = {}", this._pm);
		LOGGER.debug("_sc = {}", StringMaker.securityContextToString(this._sc));
	}
	
	protected abstract <U extends ResourceDAO<T>> U getDAO();
	//protected abstract ResourceDAO<T> getDAO();
}