package friedman.tal.mfs.timelines.events.details;

import java.util.Map;

import friedman.tal.mfs.timelines.events.EventDetails;


public class TestDetails extends EventDetails {
	private TestType _testType;
	
	public static TestDetails fromMap(Map<String, String> aMap) {
		// TODO Auto-generated method stub
		return null;
	}

}
