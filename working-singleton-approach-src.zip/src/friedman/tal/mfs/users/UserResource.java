package friedman.tal.mfs.users;

import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.appengine.api.users.UserServiceFactory;

import friedman.tal.IView;
import friedman.tal.JSPView;
import friedman.tal.Resource;
import friedman.tal.ResourceDAO;
import friedman.tal.mfs.MyFibroStoryApplication;
import friedman.tal.mfs.agreements.AgreementFormResource;
import friedman.tal.mfs.agreements.IAgreementForm;
import friedman.tal.util.StringMaker;


@Path("/signupForm")
public class UserResource extends Resource<IUserAccount> {

	public static final String SIGNUP_FORM_AGREEMENT_FORM_PARAM_NAME = "agreementForm";
	public static final String NEW_TIMELINE_REQUIRED_AGREEMENT_FORM_NAME = "newTLRequiredAgreementFormName";
	public static final String NEW_TIMELINE_REQUIRED_AGREEMENT_FORM_REVISION_NUM = "newTLRequiredAgreementFormRevisionNum";
	
	private static final String SIGNUP_FORM_LIST_URI = "/WEB-INF/SignupForm.jsp";
	
	private static final IView SIGNUP_VIEW = new JSPView(SIGNUP_FORM_LIST_URI);
	
	@GET	
	@Produces("text/html")
	public void getSignupForm(@Context HttpServletRequest request, @Context HttpServletResponse response, @Context ServletContext context) 
			throws IOException, ServletException {
		LOGGER.debug("request: "+StringMaker.requestToString(request));
		LOGGER.debug("user: "+StringMaker.googleUserToString((UserServiceFactory.getUserService().getCurrentUser())));
		MyFibroStoryApplication application = MyFibroStoryApplication.getApplication();
		
		final String requiredAgreementFormName = application.getSetting(NEW_TIMELINE_REQUIRED_AGREEMENT_FORM_NAME);
		final String requiredAgreementFormRevisionNum = application.getSetting(NEW_TIMELINE_REQUIRED_AGREEMENT_FORM_REVISION_NUM);
		
		// TODO add support for security context
		AgreementFormResource agreementFormResource = new AgreementFormResource(getPM(), getSecurityContext());
		IAgreementForm requiredAgreementForm = agreementFormResource.getAgreementForm(requiredAgreementFormName, Integer.valueOf(requiredAgreementFormRevisionNum));
		
		
		request.setAttribute(SIGNUP_FORM_AGREEMENT_FORM_PARAM_NAME, requiredAgreementForm);
		SIGNUP_VIEW.render(request, response);
	}

	@Override
	protected <U extends ResourceDAO<IUserAccount>> U getDAO() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
