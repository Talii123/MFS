package friedman.tal.mfs.timelines.events.details;

import java.util.Map;

import friedman.tal.mfs.timelines.events.EventDetails;


public class RadiationDetails extends EventDetails {

	
	public static RadiationDetails fromMap(Map<String, String> aMap) {
		// TODO Auto-generated method stub
		return null;
	}

}
