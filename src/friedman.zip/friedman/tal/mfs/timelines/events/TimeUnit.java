package friedman.tal.mfs.timelines.events;

public enum TimeUnit {
	DAYS, WEEKS, MONTHS, YEARS;
}
