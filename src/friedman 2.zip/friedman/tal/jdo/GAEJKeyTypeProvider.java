package friedman.tal.jdo;

public class GAEJKeyTypeProvider {

}
