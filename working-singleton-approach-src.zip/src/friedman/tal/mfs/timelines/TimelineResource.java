package friedman.tal.mfs.timelines;

import friedman.tal.ResourceDAO;

public class TimelineResource {
	
	/*private final TimelineDAO<TimelineJDO> dao = new TimelineDAO<TimelineJDO>(TimelineJDO.class);

	private final class TimelineDAO<T extends ITimeline> extends ResourceDAO<T> {
		private TimelineDAO(Class<T> theDBClass) {
			super(theDBClass);
		}
	}*/
}
