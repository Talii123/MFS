package friedman.tal;

import friedman.tal.mfs.users.IUserAccount;

public interface IAccessController {
	public boolean canRead(IUserAccount aUser);
	public boolean canWrite(IUserAccount aUser);
}
