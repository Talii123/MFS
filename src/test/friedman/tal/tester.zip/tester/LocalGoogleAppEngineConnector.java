package test.friedman.tal.tester;

import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.StringTokenizer;

import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.cookie.Cookie;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LocalGoogleAppEngineConnector extends AbstractGoogleAppEngineConnector implements IGoogleAppEngineConnector {

	static final String ADMIN_USERNAME_FOR_LOCAL_GOOGLE_HOST = "admin"; //"admin@google-app-engine-tester.com";

	private static final String LOCAL_GOOGLE_HOST_COOKIE_NAME = "dev_appserver_login";

	private static final HttpHost LOCAL_GOOGLE_HOST = new HttpHost("localhost", 8888);
	
	private static final String LOCAL_GOOGLE_FORM_EMAIL_INPUT_NAME = "email";

	private static final String LOCAL_GOOGLE_SIGN_IN_PATH = "/_ah/login";
	
	private static final Logger LOGGER = LoggerFactory.getLogger(LocalGoogleAppEngineConnector.class);
	

	private GoogleDevServerLoginCookieValue _devServerLoginCookieValue;
	//private boolean _isLoggedIn;
	
	protected LocalGoogleAppEngineConnector(String targetHostURI) {
		super(targetHostURI);
		//this._isLoggedIn = false;
	}
	
	public static void main(String[] args) {
		LocalGoogleAppEngineConnector connector = new LocalGoogleAppEngineConnector("");
		String userName = "tal";
		System.out.println(String.format("Trying to login as %s..", userName));
		boolean isActionSuccessful = connector.logInAs(userName, "no password");
		System.out.println("Login successful? "+ isActionSuccessful);
		
		if (isActionSuccessful) {
			System.out.println("Now attempting to log out.");
			isActionSuccessful = connector.logOut();
			System.out.println("Log out successful? "+ isActionSuccessful);
		}
	}
	
	public boolean isLoggedInAsAdmin() {
		return this._devServerLoginCookieValue != null && this._devServerLoginCookieValue.isUserAdmin();
	}
	

	@Override
	public boolean isLoggedIn() {
		//return this._isLoggedIn;
		return this._devServerLoginCookieValue != null && !this._devServerLoginCookieValue.isExpired();
	}
	
	
	@Override
	public boolean logInAsAdmin() {
		return logInAs(ADMIN_USERNAME_FOR_LOCAL_GOOGLE_HOST, "I don't need a password", true);
	}

	@Override
	public boolean logInAs(String aUsername, String aPassword) {
		return logInAs(aUsername, aPassword, false);
	}
		
	private boolean logInAs(String aUsername, String aPassword, boolean isAdmin) {		
		HttpPost logInRequest = new HttpPost(LOCAL_GOOGLE_SIGN_IN_PATH);
		HttpResponse logInResponse;
		logInRequest.setHeader(CONTENT_TYPE_HEADER_NAME, APPLICATION_X_WWW_FORM_URLENCODED_CONTENT_TYPE);
		
		//String entity = LOCAL_GOOGLE_FORM_EMAIL_INPUT_NAME + "=" + aUsername;
		//email=test%40example.com&continue=http%3A%2F%2Flocalhost%3A8888%2FmyStory&action=Log+In
		String entityTemplate = "email=%s" + "&continue=%s" + "&action=Log+In%s";
		String entity = isAdmin ? String.format(entityTemplate, aUsername, "", "&isAdmin=on") : String.format(entityTemplate, aUsername, "", "");
		
		try {
			StringEntity strEntity = new StringEntity(entity, CHARSET_UTF_8);
			logInRequest.setEntity(strEntity);			
		} catch (Exception e) {
			LOGGER.error("Caught exception while trying to sign in.  Exception: {}", e);
			return false;
		}
		
		try {
			logInResponse = this.executeRequest(LOCAL_GOOGLE_HOST, logInRequest);
			EntityUtils.consume(logInResponse.getEntity());
			
			List<Cookie> cookies = getHttpClient().getCookieStore().getCookies();
			for (Cookie cookie : cookies) {
				if (LOCAL_GOOGLE_HOST_COOKIE_NAME.equals(cookie.getName())) {
					// this cookie value provides all the info needed to determine log in status
					this._devServerLoginCookieValue = new GoogleDevServerLoginCookieValue(cookie);
					break;
				}
			}
			
			//this._isLoggedIn = loginCookie != null && !loginCookie.isExpired();
			
			if (this.isLoggedIn()) {
				setCredentials(aUsername, aPassword);
				return true;
			}
			else {
				return false;
			}
			
			
		} catch (IOException e) {
			LOGGER.error("Unable to connect to local host; log in failed.  Exception: {}", e);
			e.printStackTrace(System.err);
			return false;
		}

	}

	public boolean logOut() {
		if (!this.isLoggedIn()) {
			return false;
		}
		List<Cookie> cookies;
		DefaultHttpClient client = this.getHttpClient();
		
		// DevAppServer uses the same path for logging in and out; LOCAL_GOOGLE_SIGN_IN_PATH is the correct path for logging out
		HttpPost logOutRequest = new HttpPost(LOCAL_GOOGLE_SIGN_IN_PATH);
		HttpResponse logOutResponse;
		logOutRequest.setHeader(CONTENT_TYPE_HEADER_NAME, APPLICATION_X_WWW_FORM_URLENCODED_CONTENT_TYPE);
		
		try {
			//String entity = LOCAL_GOOGLE_FORM_EMAIL_INPUT_NAME + "=" + aUsername;
			//email=nobody%40example.com&continue=http%3A%2F%2Flocalhost%3A8888%2FmyStory&action=Log+Out
			String entityTemplate = "email=%s" + "&continue=%s" + "&action=Log+Out";
			// should not throw an NPE if we're logged in; if we're not logged in, we should have exited already
			String entity = String.format(entityTemplate, this.getCredentials().getUserPrincipal().getName(), "");			
			StringEntity strEntity = new StringEntity(entity, CHARSET_UTF_8);
			logOutRequest.setEntity(strEntity);			
		} catch (Exception e) {
			LOGGER.error("Caught exception while trying to log out.  Exception: {}", e);
			return false;
		}
		
		try {
			
			cookies = client.getCookieStore().getCookies();
			LOGGER.debug("\n\n\n before request, cookies: {}", cookies);
			
			
			logOutResponse = client.execute(LOCAL_GOOGLE_HOST, logOutRequest); 
					//this.executeRequest(LOCAL_GOOGLE_HOST, logOutRequest);
			cookies = client.getCookieStore().getCookies();
			LOGGER.debug("\n\n\n before consume, cookies: {}", cookies);
			EntityUtils.consume(logOutResponse.getEntity());
			
			cookies = client.getCookieStore().getCookies();
			LOGGER.debug("\n\n\n after consume, cookies: {} \n\n\n", cookies);
					//getHttpClient().getCookieStore().getCookies();
			for (Cookie cookie : cookies) {
				if (LOCAL_GOOGLE_HOST_COOKIE_NAME.equals(cookie.getName())) {
					this._devServerLoginCookieValue = new GoogleDevServerLoginCookieValue(cookie);
					break;
				}
			}
			if (cookies == null || cookies.size() == 0) {
				LOGGER.debug("\n\n\n why were no cookies returned?");
			}
			//this._isLoggedIn = loginCookie != null && !loginCookie.isExpired();
			 
			//return !this._isLoggedIn;
			if (!this.isLoggedIn()) {
				this.clearCredentials();
				return true;
			}
			else {
				return false;
			}
			
		} catch (IOException e) {
			LOGGER.error("Unable to connect to local host; log out failed.  Exception: {}", e);
			e.printStackTrace(System.err);
			return false;
		}


	}
	


	private static final class GoogleDevServerLoginCookieValue {
		private String _userEmail;
		private boolean _isAdmin;
		private long _expiryTime;
		
		private GoogleDevServerLoginCookieValue(Cookie aCookie) {
			// assert: aCookie is not null
			// assert: aCookie.getValue is not null
			StringTokenizer tokenizer = new StringTokenizer(aCookie.getValue(), ":");
			if (tokenizer.hasMoreTokens()) {
				this._userEmail = tokenizer.nextToken();
			}
			if (tokenizer.hasMoreTokens()) {
				this._isAdmin = Boolean.valueOf(tokenizer.nextToken());
			}
			
			Date expiryDate = aCookie.getExpiryDate();
			LOGGER.debug("expiryDate: {}", expiryDate);
			this._expiryTime = expiryDate != null ? expiryDate.getTime() : 0;
		}
		
		public String getUserEmail() {
			return this._userEmail;
		}
		
		public boolean isUserAdmin() {
			return this._isAdmin;
		}
		
		public boolean isExpired() {
			long currentTime = System.currentTimeMillis();
			LOGGER.debug("this._expiryTime: {}, System.currentTimeMillis(): {}", this._expiryTime, currentTime);
			return this._expiryTime > 0 &&  this._expiryTime < currentTime;
		}
		
		public long getExpiryTime() {
			return this._expiryTime;
		}
	}

}
