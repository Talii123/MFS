package friedman.tal.mfs.agreements;

import javax.jdo.PersistenceManager;
import javax.ws.rs.core.SecurityContext;

import friedman.tal.Resource;
import friedman.tal.ResourceDAO;
import friedman.tal.mfs.users.IUserAccount;
import friedman.tal.mfs.users.IUserInfo;

public class AgreementResource extends Resource<IAgreement> {
	
	//private final AgreementDAO<AgreementJDO> _dao;// = new AgreementDAO(AgreementJDO.class);

	
	public AgreementResource() {
		//this._dao = new AgreementDAO(AgreementJDO.class);
	}
	
	public AgreementResource(PersistenceManager aPM, SecurityContext anSC) {
		super(aPM, anSC);
		//this._dao = new AgreementDAO(AgreementJDO.class, aPM, anSC);
	}
	
	// do not make this available to external clients outside the application; NO HTTP clients
	/**
	 * 
	 * @param anAgreer the account corresponding to the user making the agreement
	 * @param anAgreerInfo basic info about the user that submitted the request to enter into the agreement
	 * @param anAgreementForm the terms of the agreement
	 * @param pm the persistence manager to use; this method should be called in the context of an existing Transaction 
	 */
	public void makeAgreement(IUserAccount anAgreer, IUserInfo anAgreerInfo, IAgreementForm anAgreementForm) {
		getDAO().makeAgreement(anAgreer, anAgreerInfo, anAgreementForm);
	}
	
	protected AgreementDAO<? extends IAgreement> getDAO() {
		return new AgreementDAO<AgreementJDO>(AgreementJDO.class, getPM(), getSecurityContext());		
	}
	
	private final class AgreementDAO<T extends IAgreement> extends ResourceDAO<T> {
		
//		private AgreementDAO(Class<T> theDBClass) {
//			super(theDBClass);
//		}
		
		private AgreementDAO(Class<T> theDBClass, PersistenceManager aPM, SecurityContext anSC) {
			super(theDBClass, aPM, anSC);
		}
		
		private IAgreement makeAgreement(IUserAccount anAgreer, IUserInfo anAgreerInfo, IAgreementForm anAgreementForm) {
			IAgreement newAgreement = new AgreementJDO(anAgreer, anAgreerInfo, anAgreementForm);
			this._pm.makePersistent(newAgreement);
			return newAgreement;
		}
	}
}
