package friedman.tal.mfs.proto;

public interface TestInerface {

	public enum Nested {
		TEST1, TEST2
	}
	
	
}
