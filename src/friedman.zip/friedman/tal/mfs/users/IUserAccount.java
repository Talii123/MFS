package friedman.tal.mfs.users;

import friedman.tal.mfs.agreements.IAgreement;
import friedman.tal.mfs.timelines.ITimeline;

public interface IUserAccount {

	//public void addAgreement(IAgreement agreement);

	public abstract String getName();

	public void setTimeline(ITimeline timeline);

	public ITimeline getTimeline();

	public <T extends IAgreement> void addAgreement(T anAgreement);

}