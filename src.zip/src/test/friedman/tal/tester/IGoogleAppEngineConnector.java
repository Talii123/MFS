package test.friedman.tal.tester;

public interface IGoogleAppEngineConnector {

	public static final String CHARSET_UTF_8 = "UTF-8";
	public static final String APPLICATION_X_WWW_FORM_URLENCODED_CONTENT_TYPE = "application/x-www-form-urlencoded";
	public static final String CONTENT_TYPE_HEADER_NAME = "Content-Type";

	public boolean logInAs(String aUsername, String aPassword);

	public boolean isLoggedIn();

	public boolean logInAsAdmin();
}
