package friedman.tal.mfs.timelines;

import javax.jdo.annotations.PersistenceCapable;

import friedman.tal.mfs.users.IUserAccount;

@PersistenceCapable
public class TimelineJDO implements ITimeline {

	public TimelineJDO(IUserAccount owner) {
		owner.setTimeline(this);
		//owner.get
	}
}
