package friedman.tal;


public class NotSet {
	public static final Long LONG = null;
	public static final Boolean BOOLEAN = null;
	public static final Byte BYTE = null;
	public static final String STRING = null;
}
