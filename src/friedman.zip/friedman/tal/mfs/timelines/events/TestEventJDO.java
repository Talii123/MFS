package friedman.tal.mfs.timelines.events;

import javax.jdo.annotations.PersistenceCapable;
import javax.jdo.annotations.Persistent;

import friedman.tal.jdo.TypedKey;
import friedman.tal.mfs.timelines.EventJDO;
import friedman.tal.mfs.timelines.EventTO;
import friedman.tal.mfs.timelines.ITimeline;
import friedman.tal.mfs.timelines.events.details.TestDetails;

@PersistenceCapable
public class TestEventJDO extends EventJDO {

	@Persistent
	private TestDetails _eventDetails;
	
	public TestEventJDO(EventTO anEvent, TypedKey<? extends ITimeline, String> aTimelineKey) {
		super(anEvent, aTimelineKey);
		this._eventDetails = (TestDetails)anEvent.getTypeDetails();
	}

	
}
