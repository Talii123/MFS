package friedman.tal.mfs.timelines.events;

import java.util.Date;
import java.util.Map;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.Range;

import friedman.tal.resources.IProtectableResource;
import friedman.tal.validation.ValidDateRange;

@ValidDateRange
public interface IEvent extends IProtectableResource {

	public String getID();
	
	public Date getStartDate();
	public Date getEndDate();
	
	@NotBlank
	public String getTitle();
	
	
	public String getIcon();
	
	/*@Range(min=-1, max=5)
	public byte getTypeIndex();*/
	
	@NotNull
	public EventType getType();
	
    @Valid
	public EventDetails getTypeDetails();
	//public Map<String, String> getTypeDetails();
	
}
