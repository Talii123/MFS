package friedman.tal.mfs.timelines.events.details;

import java.util.Map;

import friedman.tal.mfs.timelines.events.EventDetails;


public class ImmunoDetails extends EventDetails {

	public static ImmunoDetails fromMap(Map<String, String> aMap) {
		// TODO Auto-generated method stub
		return null;
	}
}
