package test.friedman.tal.tester;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

import org.jboss.resteasy.client.ProxyFactory;
import org.jboss.resteasy.plugins.providers.RegisterBuiltin;
import org.jboss.resteasy.spi.ResteasyProviderFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import friedman.tal.mfs.resources.ITimelineResource;
import friedman.tal.mfs.timelines.ITimeline;


public class AppEngineTester implements IGoogleAppEngineConnector {

	private static final String DEFAULT_APP_VERSION = "0-7";
	private static final String DEFAULT_APP_HOSTNAME = "fibrolamellar.appspot.com";
	

	private static final String GOOGLE_APP_ENGINE_VERSION_PATTERN_STR = "^[\\d]+\\-[\\d]+$";


	public static final Logger LOGGER = LoggerFactory.getLogger(AppEngineTester.class);	
	
	
	private static Map<String, TesterParam> paramNameMap = new HashMap<String, TesterParam>();
	
	private String _hostname = DEFAULT_APP_HOSTNAME;
	private String _version = DEFAULT_APP_VERSION;
	private String _targetHostURI;
	
	private AbstractGoogleAppEngineConnector _connector;
	

	
	public enum TesterParam {
		HOSTNAME(new String[]{"h", "host", "hostname"}), 
		VERSION(new String[]{"v", "version"});
			
		private String[] paramNames;
		
		private TesterParam(String[] theParamNames) {
			for (String paramName : theParamNames) {
				if (paramNameMap.containsKey(paramName)) {
					// should probably be some other exception as this is a compile time error - developer should have known better!
					throw new IllegalArgumentException("Can't use the same parameter name for multiple parameters!");
				}
				paramNameMap.put(paramName, this);
			}				
			paramNames = theParamNames;				
		}
		
		private String[] getAliases() {
			return Arrays.copyOf(paramNames, paramNames.length);
		}
	}
	
	public static void main(String[] args) throws Exception {
		//_logger.debug("args: {}", args);
		String hostname = DEFAULT_APP_HOSTNAME;
		String version = DEFAULT_APP_VERSION;

		for (String arg: args) {
			LOGGER.debug("arg: {}", arg);
			String[] argParts = arg.split(":");
			if (argParts == null || argParts.length != 2) {
				LOGGER.debug("Skipping argument {} since it is not formatted properly.", arg);
				continue;
			}
			
			String key = argParts[0];
			String value = argParts[1];
			if (key.startsWith("-")) {
				key = key.substring(1);
			}
			
			TesterParam testerParam = paramNameMap.get(key);
			if (TesterParam.HOSTNAME.equals(testerParam)) {
				hostname = value;
			}
			else if (TesterParam.VERSION.equals(testerParam)) {
				if (!"current".equals(value)) { // need to support a way for tester to specify to test the current version
					version = value;	
				}
				else {
					version = "";
				}
			}
		}
		
		
		
		AppEngineTester tester =  new AppEngineTester(hostname, version, false);
														//new AppEngineTester(DEFAULT_APP_HOSTNAME, DEFAULT_APP_VERSION);
		tester.logInAsAdmin();
		
		tester.doGetTimeline();
	}


	public AppEngineTester(String anAppHostname, String anAppVersion, boolean isTestDeployedCode) throws Exception {
		this._hostname = anAppHostname;
		this._version = anAppVersion;

		RegisterBuiltin.register(ResteasyProviderFactory.getInstance());
				
		String targetHostURI = Pattern.matches(GOOGLE_APP_ENGINE_VERSION_PATTERN_STR, this._version) ? this._version+"."+this._hostname : this._hostname;
		this._targetHostURI = targetHostURI;
		LOGGER.debug("targetHostURI={}", targetHostURI);
		
		if (isTestDeployedCode) {
			this._connector = new RemoteGoogleAppEngineConnector(targetHostURI);
		}
		else {
			this._connector = new LocalGoogleAppEngineConnector(targetHostURI);
		}

	}    
	
	public void doGetTimeline() {
			
		ITimelineResource timelineResourceProxy = ProxyFactory.create(ITimelineResource.class, this._targetHostURI , this._connector.getClientExecutor());
		ITimeline timeline;
		try {
			timeline = timelineResourceProxy.getPublicTimelineJSON("Tulliver");
			LOGGER.debug("timeline: {}", timeline);
		} catch (Exception e) {
			LOGGER.error("caught exception while trying to get public timeline; exception: {}", e);
		}
		
	}
	
	
	

	@Override
	public boolean logInAs(String aUsername, String aPassword) {
		return this._connector.logInAs(aUsername, aPassword);
	}


	@Override
	public boolean isLoggedIn() {
		return this._connector.isLoggedIn();
	}


	@Override
	public boolean logInAsAdmin() {
		return this._connector.logInAsAdmin();
	}	
	
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(this.getClass().getName());
		sb.append("\n_hostname=").append(this._hostname);
		sb.append("\n_version=").append(this._version);
		sb.append("\n_targetHostURI=").append(this._targetHostURI);
		return sb.toString();
	}

}
