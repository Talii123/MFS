package friedman.tal.mfs.timelines;

import java.io.IOException;
import java.util.List;

import javax.jdo.PersistenceManager;
import javax.jdo.Query;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import friedman.tal.IView;
import friedman.tal.JSPView;
import friedman.tal.mfs.timelines.events.EventJDOFactory;
import friedman.tal.mfs.users.IUserAccount;
import friedman.tal.mfs.users.UserAccountJDO;
import friedman.tal.resources.IResourceDAOContext;
import friedman.tal.resources.Resource;
import friedman.tal.resources.ResourceDAO;
import friedman.tal.util.Utils;

@Path("")	// TODO: find out: is this the same as @Path("/")?  I'd rather not use the slash
public class TimelineResource extends Resource<ITimeline> {

	private static final String PUBLIC_TIMELINE_RESOURCE_URL = "public/{timelineID}";

	public static final String MY_TIMELINE_RESOURCE_URL = "/myStory";

	private static final String MY_TIMELINE_RESOURCE_EVENTS_URL = MY_TIMELINE_RESOURCE_URL + "/events";
	
	private static final String TIMELINE_VIEW_JSP_URL = "/WEB-INF/TimelineView.jsp";
	private static final IView TIMELINE_VIEW = new JSPView(TimelineResource.TIMELINE_VIEW_JSP_URL);

	public TimelineResource(IResourceDAOContext aResourceDAOContext) {
		super(aResourceDAOContext);
	}
	
	public TimelineResource(IResourceDAOContext aResourceDAOContext, PersistenceManager aPM) {
		super(aResourceDAOContext, aPM);
	}
	
	@Deprecated
	public TimelineResource() {		
	}
	
	// TODO: is there a way to use an interface rather than a concrete type?
	@POST
	@Path(MY_TIMELINE_RESOURCE_EVENTS_URL)
	@Consumes({MediaType.APPLICATION_JSON, "application/*+json"})
	public void addEventForCurrentUser(EventTO anEvent) {
		LOGGER.debug("received event: '{}' ", anEvent);
				
		TimelineDAO<TimelineJDO> timelineDAO = (TimelineDAO<TimelineJDO>) getDAO();
		// TODO: confirm: should logic to transform the event object to a JDO and validate it be placed here rather than at the DAO level?		
		EventJDO eventJDO = timelineDAO.convert(anEvent);
		
		// the DAO only returns validated EventJDOs
		timelineDAO.addEventForCurrentUser(eventJDO);
	}
	
	@GET
	@Path(TimelineResource.MY_TIMELINE_RESOURCE_URL)
	@Produces("text/html")
	public void getMyTimeline() throws ServletException, IOException {
		ITimeline timeline = getDAO().getCurrentUserTimeline();
		renderTimeline(timeline, getDAOContext());
	}
	
	
	@GET
	@Path(PUBLIC_TIMELINE_RESOURCE_URL)
	@Produces("text/html")
	public Response getPublicTimeline(@PathParam("timelineID") String aTimelineID) throws ServletException, IOException {
		TimelineDAO<? extends ITimeline> timelineDAO = getDAO();
		
		ITimeline publicTimeline = timelineDAO.findTimelineByPublicID(aTimelineID);
		if (publicTimeline == null) {
			return Response.status(Status.NOT_FOUND).build();
		}
		
		renderTimeline(publicTimeline, getDAOContext());
		return null;
	}
	
	@Path("timelines")
	@POST
	@Consumes(Utils.HTML_FORM_MEDIATYPE)
	public void createAndRenderTimeline(MultivaluedMap<String, String> aTimelineSpecForm) throws ServletException, IOException {
		String timelineID = aTimelineSpecForm.getFirst("timelineID");
		ITimeline newTimeline = createTimeline(timelineID);
		renderTimeline(newTimeline, getDAOContext());
	}
	
	
	public ITimeline createTimeline(String timelineID) {
		ITimeline newTimeline = null;
		timelineID = Utils.getValueOrEmptyString(timelineID);
		boolean hasTimelineID = timelineID.length() > 0;
		TimelineDAO<? extends ITimeline> timelineDAO = null;
		
		try {			
			timelineDAO = getDAO();
			timelineDAO.initIfLocalTrxn();
			
			IUserAccount userAccount = timelineDAO.getCurrentUserAccount();
			
			checkRequiredAgreements(userAccount);
			checkHasNoTimeline(userAccount);			
			
			if (hasTimelineID) {
				newTimeline = timelineDAO.createTimeline((UserAccountJDO)userAccount, timelineID);
			}
			else {
				newTimeline = timelineDAO.createTimeline((UserAccountJDO)userAccount);
			}
			
			LOGGER.debug("before committing transaction, newTimeline is: \n {}", newTimeline);
			timelineDAO.commitIfLocalTrxn();
		} finally {
			if (timelineDAO != null) {
				timelineDAO.cleanupIfLocalTrxn();	
			}			
		}

		return newTimeline;
	}

	
	private void checkRequiredAgreements(IUserAccount aUserAccount) {
		// TODO Auto-generated method stub
		
	}

	private void checkHasNoTimeline(IUserAccount aUser) {
		if (aUser.getTimeline() != null) {
			throw new IllegalArgumentException("User already has a timeline!");
		}
	}
	
	private void renderTimeline(ITimeline timeline, IResourceDAOContext myContext)
			throws ServletException, IOException {
		HttpServletRequest request = myContext.getRequest();
		request.setAttribute("timeline", timeline);
		TimelineResource.TIMELINE_VIEW.render(request, myContext.getResponse());
	}	
	
	/*public void deleteTimeline(IUserAccount aUser) {
		if (aUser.getTimeline() == null) {
			throw new IllegalArgumentException("User does not have a timeline!");
		}
		
		getDAO().deleteTimeline(aUser);
	}*/

	@SuppressWarnings("unchecked")
	@Override
	protected TimelineDAO<? extends ITimeline> getDAO() {
		logContextFields();
		return new TimelineDAO<TimelineJDO>(TimelineJDO.class, getDAOContext());
	}	
	
	private final class TimelineDAO<T extends ITimeline> extends ResourceDAO<T> {

		protected TimelineDAO(Class<T> aDBClass, IResourceDAOContext aDAOContext) {
			super(aDBClass, aDAOContext);
		}

		private ITimeline findTimelineByPublicID(String aTimelineID) {
			ITimeline timeline = null;
			Query q = this._pm.newQuery(this._theDBClass);
			q.setFilter("_publicID == timelineIDParam");
			q.declareParameters("String timelineIDParam");
			List<? extends ITimeline> results = (List<? extends ITimeline>) q.execute(aTimelineID);
			int numResults = results != null ? results.size() : 0;
			
			if (numResults > 0) {
				if (numResults > 1) {
					_logger.warn("Found more than one object with the supposedly unique _publicID of: '{}' ", aTimelineID);
				}
				
				timeline = results.get(0);
			}

			return timeline;
		}

		private IUserAccount getCurrentUserAccount() {
			return super.getUserAccount();
		}

		private ITimeline getCurrentUserTimeline() {
			return getUserAccount().getTimeline();
		}

		private ITimeline createTimeline(UserAccountJDO aUser) {
			ITimeline timeline = new TimelineJDO(aUser); 
			return timeline;
		}
		
		private ITimeline createTimeline(UserAccountJDO aUser, String aTimelineID) {			
			PublicTimelineID publicID = ResourceDAO.makeUniqueID(PublicTimelineID.class, aTimelineID, this._pm);
			ITimeline timeline = new TimelineJDO(aUser, publicID.getUniqueString());
			return timeline;
		}		
		
		
		private void addEventForCurrentUser(EventJDO anEvent) {
			this.initIfLocalTrxn();
			
			try {
				//wrap lookup of current timeline in the same transaction context as the adding of the event so that
				// if the timeline has been modified outside the transaction, this add event operation will fail.
				// TODO: verify this is the most appropriate behaviour
				TimelineJDO timeline = (TimelineJDO)getCurrentUserTimeline();
				addEventToTimeline(anEvent, timeline);
				
				this.commitIfLocalTrxn();
			} finally {
				this.cleanupIfLocalTrxn();
			}
			
		}

		
		private void addEventToTimeline(EventJDO eventJDO, TimelineJDO aTimeline) {
			
			
			// now that the event has been created and validated, add it to the timeline within a local transaction since
			// multiple objects are being updated 
			
			this.initIfLocalTrxn();
			try {
								
				// since event is in the same entity group as the timeline that forms an unowned relationship with it, they can be
				// updated within the same transaction.
				// the new event added to the timeline will be persisted once the transaction is commited
				aTimeline.addEvent(eventJDO);
				
				try {
					LOGGER.debug("aTimeline.getKey(): {}", aTimeline.getKey());
					
					LOGGER.debug("eventJDO.getKey(): {}", eventJDO.getKey());					
				} catch (IllegalAccessException e) {
					LOGGER.error("That's weird.  I caught an exception while debugging.  {}", e);
				}

				
				// this is needed because the relationship between the Timeline and the Event is unowned
				this._pm.makePersistent(eventJDO);

				this.commitIfLocalTrxn();
			} finally {
				this.cleanupIfLocalTrxn();
			}		
			
		}

		private EventJDO convert(EventTO anEvent) {
			EventJDO eventJDO = EventJDOFactory.createEvent(anEvent);
			validateEvent(eventJDO);			
			
			return eventJDO;
		}
		
		private void validateEvent(EventJDO anEventJDO) {
			
		}
		
		/*public void deleteTimeline(IUserAccount aUser) {
			_pm.deletePersistent(aUser.getTimeline());
		}*/
		
	}
	
/*
 * miscelaneous stuff
 * 
 * 			
			/*try {
				eventJDO = (EventJDO)anEvent;
			} catch (ClassCastException e) {
			
			LOGGER.debug("anEvent is not of type EventJDO, so cannot cast it. Trying to create a new EventJDO using a constructor that accepts the EventTO object.  anEvent = {}", anEvent);
			try {*/
				//eventJDO = new EventJDO((EventTO)anEvent);
	
	
	/*} catch (ClassCastException e2) {
	// LOGGER.debug("Cannot cast anEvent to type EventTO either.  Have to create an EventJDO object from it; anEvent= {}", anEvent);
	// eventJDO = new EventJDO(anEvent);
	LOGGER.error("Cannot cast anEvent to type EventTO either.  Don't have another constructor for EventTO right now, so unable to create it. anEvent= {}", anEvent);
	throw new IllegalArgumentException(e2);
}
	
}

 * 	
 */
}
