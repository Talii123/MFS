/*if (typeof SimileAjax == "undefined") {
    var SimileAjax = {
        loaded:                 false,
        loadingScriptsCount:    0,
        error:                  null,
        params:                 { bundle:"true" },
        Platform: {},
        urlPrefix: "javascripts/timeline/timeline_ajax/"
    };

}
*/

var SimileAjax = SimileAjax || {
	"loaded"	: 	false,
	"loadingScriptsCount"	: 	0,
	"error" 	: 	null,
	"params"	: 	{	bundle : "true"	},
	"Platform"	: 	{},
	"urlPrefix" : 	"/timelineResources/" 
};
