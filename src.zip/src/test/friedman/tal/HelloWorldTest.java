package test.friedman.tal;


import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import proto.test.IHelloWorld;

import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.client.AuthCache;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.protocol.ClientContext;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.client.BasicAuthCache;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.util.EntityUtils;
import org.jboss.resteasy.client.ProxyFactory;
import org.jboss.resteasy.client.core.executors.ApacheHttpClient4Executor;
import org.jboss.resteasy.plugins.providers.RegisterBuiltin;
import org.jboss.resteasy.spi.ResteasyProviderFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;



public class HelloWorldTest {
	
	public static final Logger LOGGER = LoggerFactory.getLogger(HelloWorldTest.class);

	
	private static HttpPost getPostRequestForGoogleSignIn(String aGoogleSignInForm) throws Exception {
		LOGGER.debug("aGoogleSignInForm: {}", aGoogleSignInForm);
		Matcher formTagMatcher = Pattern.compile("<form[^>]+>").matcher(aGoogleSignInForm);
		String formTag = formTagMatcher.find() ? formTagMatcher.group() : "";
		LOGGER.debug("formTag: {}", formTag);
		
		if ("".equals(formTag)) throw new RuntimeException("error parsing form tag!");
		
		Matcher actionMatcher = Pattern.compile("action=\"([^\"]+)\"|action=\'([^\']+)\'").matcher(formTag);
		String action = actionMatcher.find() ? actionMatcher.group(1) : "";
		LOGGER.debug("action: {}", action);
		
		String entityString = getPostEntityFromGoogleSignInForm(aGoogleSignInForm);
		StringEntity entity = new StringEntity(entityString, "UTF-8");
		LOGGER.debug("entity: {}", entityString);
		
		HttpPost postRequest = new HttpPost(action);
		postRequest.setHeader("Content-Type", "application/x-www-form-urlencoded");
		postRequest.setEntity(entity);
		
		return postRequest;
	}
	
	private static String getPostEntityFromGoogleSignInForm(String aGoogleSignInForm) {
		final Pattern inputPattern = Pattern.compile("<input [^>]+>");
		final Pattern attrPattern = Pattern.compile("\\s*(type|name|value|id)\\=(\\'[^\\']*\\'|\\\"[^\\\"]*\\\")\\s*");
		StringBuilder entitySB = new StringBuilder();
		
		final Matcher inputMatcher = inputPattern.matcher(aGoogleSignInForm);
		String paramName = "";
		String paramValue = "";
		while (inputMatcher.find()) {
			String anInput = inputMatcher.group();
			Matcher attrMatcher = attrPattern.matcher(anInput);

			while (attrMatcher.find()) {
				String group0 = attrMatcher.group(0);
				String group1 = attrMatcher.group(1);
				String group2 = attrMatcher.group(2);
				//String group3 = attrMatcher.group(3);
				//String group4 = attrMatcher.group(4);
				//String group5 = attrMatcher.group(5);
				//String group6 = attrMatcher.group(6);
				//String group7 = attrMatcher.group(7);
				String attrName = attrMatcher.group(1);
				String attrValue = attrMatcher.group(2);
				attrValue = attrValue.substring(1, attrValue.length()-1);
				if ("name".equals(attrName)) {
					paramName = attrValue;
				}
				else if ("value".equals(attrName)) {
					paramValue = attrValue;
				}
			}
			
			if (!"".equals(paramName)) {
				
				if ("Email".equals(paramName)) paramValue = "johnny.test.appengine@gmail.com";
				if ("Passwd".equals(paramName)) paramValue = "testing/1234/";
				entitySB.append(paramName).append("=").append(paramValue).append("&");
				paramName = paramValue = "";
			}
			
		}
		
		entitySB.setLength(entitySB.length()-1);
		String test = entitySB.toString();
		return entitySB.toString();
	}
	
	public static void main(String[] args) throws Exception {
		
		RegisterBuiltin.register(ResteasyProviderFactory.getInstance());
		
		System.out.println("Is this thing on?");
		LOGGER.info("huh?");
		//_logger.debug("calling delete for some dumb reason...");
		
		HttpHost targetHost = new HttpHost("0-7.fibrolamellar.appspot.com");
		DefaultHttpClient httpClient = new DefaultHttpClient();
		AuthCache authCache = new BasicAuthCache();
		BasicScheme basicAuth = new BasicScheme();
		authCache.put(targetHost, basicAuth);
		BasicHttpContext localContext = new BasicHttpContext();
		localContext.setAttribute(ClientContext.AUTH_CACHE, authCache);
		
		
		ApacheHttpClient4Executor executor = new ApacheHttpClient4Executor(httpClient, localContext);
		
        LOGGER.info("Before GET request, cookies=");
        TestUtils.printCookies((DefaultHttpClient)((ApacheHttpClient4Executor)executor).getHttpClient());
		
        HttpGet getLoginURL = new HttpGet("/autologin");
        HttpResponse response = httpClient.execute(targetHost, getLoginURL, localContext);
        
        /*Header header = response.getFirstHeader("x-auto-login");
        for (int i=0; i < 10; ++i) {
        	_logger.info("header: {}={}", header.getName(), header.getValue());
        }*/
        //EntityUtils.consume(response.getEntity());

        StringBuilder buffer = new StringBuilder();
        String line = "";
        BufferedReader reader = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
        while ((line = reader.readLine()) != null) {
        	buffer.append(line);
        }
        
        
    	/*httpClient.getCredentialsProvider().setCredentials(
                new AuthScope(targetHost.getHostName(), targetHost.getPort(), "google.com"),
                new UsernamePasswordCredentials("johnny.test.appengine@gmail.com", "testing/1234/"));		
*/
		
		/*List<Cookie> cookies = httpClient.getCookieStore().getCookies();
		boolean hasGAPSCookie = false;
		boolean hasACSIDCookie = false;
		String cookieName = "";
		for (Cookie cookie: cookies) {
			cookieName = cookie.getName();
			if ("GAPS".equalsIgnoreCase(cookieName)) {
				hasGAPSCookie = true;
			}
			else if ("ACSID".equalsIgnoreCase(cookieName)) {
				hasACSIDCookie = true;
			}
		}
		_logger.info("hasGAPSCookie? {}  hasASCIDCookie? {}", hasGAPSCookie, hasACSIDCookie);*/
		
       //HttpPost signin = new HttpPost("https://accounts.google.com/ServiceLoginAuth?service=ah&continue=https://appengine.google.com/_ah/conflogin%3Fcontinue%3Dhttp://0-7.fibrolamellar.appspot.com/autologin");			   
	   //signin.setEntity(new StringEntity("Email=johnny.test.appengine&Passwd=testing/1234/", "UTF-8"));
    	
       
    	int startIndex = buffer.indexOf("<form");
    	if (startIndex >= 0) {
    		int endIndex = buffer.indexOf("</form", startIndex);
    		
        	HttpPost signin = getPostRequestForGoogleSignIn(buffer.substring(startIndex, endIndex));
        	    	LOGGER.debug("post URI: {}", signin.getURI());
        	response = httpClient.execute(new HttpHost("accounts.google.com", 443, "https"), signin, localContext);           
        	EntityUtils.consume(response.getEntity());
        	

            
            LOGGER.debug("Am I logged in now?  Gonna try my request again.");
            LOGGER.debug("Cookies:");
            TestUtils.printCookies(httpClient);
            
            
            HttpGet getRequest = new HttpGet("/hello");
    		response = httpClient.execute(targetHost, getRequest, localContext);
            LOGGER.debug("And now my cookies are:");
            TestUtils.printCookies(httpClient);    		
    		
    		//EntityUtils.consume(response.getEntity());
    		LOGGER.debug("the response to my hello request was: {}", EntityUtils.toString(response.getEntity()));
            
            IHelloWorld helloWorldClient = ProxyFactory.create(IHelloWorld.class, "http://0-7.fibrolamellar.appspot.com", executor);

            LOGGER.debug("Server says: {}", helloWorldClient.getSalutation());//.substring(0, 10));
            LOGGER.debug("Now trying to delete...  Server Says: {}", helloWorldClient.deleteHello());
            LOGGER.info("After GET request, cookies=");
            TestUtils.printCookies((DefaultHttpClient)((ApacheHttpClient4Executor)executor).getHttpClient());				
            LOGGER.debug("PUT? {}", helloWorldClient.fakePut());
    	}
    	

        
        
		
		
	}
	
	
	 /*  private static ClientExecutor getAuthenticatedClientExecutor()  {

	        //HttpHost targetHost = new HttpHost("http://0-7.fibrolamellar.appspot.com"); //new HttpHost("localhost", 80, "http");
		   HttpHost targetHost = new HttpHost("google.com", 443); //new HttpHost("https://google.com");
		   
	        DefaultHttpClient httpClient = new DefaultHttpClient();
        	httpClient.getCredentialsProvider().setCredentials(
                    new AuthScope(targetHost.getHostName(), targetHost.getPort()),
                    new UsernamePasswordCredentials("johnny.test.appengine@gmail.com", "testing/1234/"));
        	

            // Create AuthCache instance
            AuthCache authCache = new BasicAuthCache();
            // Generate BASIC scheme object and add it to the local
            // auth cache
            BasicScheme basicAuth = new BasicScheme();
            authCache.put(targetHost, basicAuth);

            // Add AuthCache to the execution context
            BasicHttpContext localcontext = new BasicHttpContext();
            localcontext.setAttribute(ClientContext.AUTH_CACHE, authCache);     

            return new ApacheHttpClient4Executor(httpClient, localcontext);

	    }*/
	   
	   
	   /*private static ClientExecutor getAuthenticatedClientExecutor() {
		   ClientExecutor executor = null;
		   try {
			   DefaultHttpClient httpClient = new DefaultHttpClient();

			   //HttpHost targetHost = new HttpHost("https://google.com");
			   HttpHost targetHost = new HttpHost("appengine.google.com", 443, "https");
			   httpClient.getCredentialsProvider().setCredentials(
	                    new AuthScope(targetHost.getHostName(), targetHost.getPort()),
	                    new UsernamePasswordCredentials("johnny.test.appengine@gmail.com", "testing/1234/"));
			   
			   targetHost = new HttpHost("accounts.google.com", 443, "https");
			   httpClient.getCredentialsProvider().setCredentials(
	                    new AuthScope(targetHost.getHostName(), targetHost.getPort()),
	                    new UsernamePasswordCredentials("johnny.test.appengine@gmail.com", "testing/1234/"));			   
			   
			   
	            // Create AuthCache instance
	            AuthCache authCache = new BasicAuthCache();
	            // Generate BASIC scheme object and add it to the local
	            // auth cache
	            BasicScheme basicAuth = new BasicScheme();
	            authCache.put(targetHost, basicAuth);

	            // Add AuthCache to the execution context
	            BasicHttpContext localContext = new BasicHttpContext();
	            localContext.setAttribute(ClientContext.AUTH_CACHE, authCache);    
			  // HttpPost signin = new HttpPost("https://accounts.google.com/ServiceLogin?service=ah");

	           _logger.info("Before any requests, cookies=");
	           printCookies(httpClient);
			   HttpPost signin = new HttpPost("https://accounts.google.com/ServiceLogin?service=ah&passive=true&continue=https://appengine.google.com/_ah/conflogin%3Fcontinue%3Dhttp://0-7.fibrolamellar.appspot.com/");			   
			   signin.setEntity(new StringEntity("Email=johnny.test.appengine&Passwd=testing/1234/", "UTF-8"));
	
	           HttpResponse response = httpClient.execute(targetHost, signin, localContext);           
	           EntityUtils.consume(response.getEntity());

	           _logger.info("After sign in, cookies=");
	           printCookies(httpClient);	           
	           
	           executor = new ApacheHttpClient4Executor(httpClient, localContext);
		   } catch (Exception e) {
			   System.err.println(e.getMessage());
			   e.printStackTrace();
		   } 

		   return executor;
		}*/
	   
	   
	   
}



