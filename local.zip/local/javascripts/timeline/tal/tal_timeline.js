
/*window.Timeline = window.Timeline || {};
window.Timeline.DateTime = window.SimileAjax.DateTime; // for backward compatibility

Timeline.serverLocale = "en";
Timeline.clientLocale = "en";*/

window.Timeline = window.Timeline || {
	"DateTime"		: 	window.SimileAjax.DateTime, 
	"serverLocale"	: 	"en",
	"clientLocale"	: 	"en", 
	"urlPrefix" 	: 	"/timelineResources/"
};
