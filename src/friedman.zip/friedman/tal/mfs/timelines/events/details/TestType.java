package friedman.tal.mfs.timelines.events.details;

public enum TestType {
	CT_SCAN, MRI, ULTRASOUND;
}
