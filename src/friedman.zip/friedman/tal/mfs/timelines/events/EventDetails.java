package friedman.tal.mfs.timelines.events;


public abstract class EventDetails implements IEventDetails {

	
}
