package friedman.tal.mfs.proto.test;

import java.util.List;

import javax.jdo.PersistenceManager;
import javax.jdo.Query;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import friedman.tal.util.PMF;

@Path("unique")
public class TestUniquenessResource {

	public static Logger LOGGER = LoggerFactory.getLogger(TestUniquenessResource.class);
	
	@GET
	@Produces("text/plain")
	public String doTest(@QueryParam("value") String value, @QueryParam("create") boolean isCreateRequested) {
		PersistenceManager pm = PMF.getNewPM();
		String response = "";
		try {
			if (isCreateRequested) {
				TestUniquenessLongJDO jdo = new TestUniquenessLongJDO(value);
				pm.makePersistent(jdo);
				response = jdo.toString();
			}
			else {				
				Query q = pm.newQuery(TestUniquenessLongJDO.class);
				q.setFilter("_field == fieldValueParam");
				q.declareParameters("String fieldValueParam");
				@SuppressWarnings("unchecked")
				List<TestUniquenessLongJDO> results = (List<TestUniquenessLongJDO>) q.execute(value);
				
				if (results.size() > 1) {
					LOGGER.error("Error: more than one JDO has value='{}'!", value);
				}
				
				StringBuilder sb = new StringBuilder();
				for (TestUniquenessLongJDO jdo : results) {
					sb.append("\n").append(jdo.toString());
				}
				response = sb.toString();
			}			
		} catch (Throwable t) {
			LOGGER.error("caught exception while performing test; exception ={}", t);
		} finally {
			pm.close();
		}
		
		return response;

	}
}
