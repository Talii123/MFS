package friedman.tal.mfs.agreements;

import java.util.Date;

public interface IAgreementForm {

	public String getID();
	public String getName();
	public Date getCreatedDate();
	public int getRevisionNum();
	public String getFirstRelease();	
	public String getText();
	public abstract String getCreator();
}
