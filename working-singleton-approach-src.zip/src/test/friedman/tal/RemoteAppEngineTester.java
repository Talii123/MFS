package test.friedman.tal;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.client.AuthCache;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.protocol.ClientContext;
import org.apache.http.cookie.Cookie;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.client.BasicAuthCache;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.util.EntityUtils;

import org.jboss.resteasy.client.core.executors.ApacheHttpClient4Executor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class RemoteAppEngineTester {

	private static final String GOOGLE_APP_ENGINE_VERSION_PATTERN_STR = "^[\\d]+\\-[\\d]+$";
	private static final String DEFAULT_APP_VERSION = "0-7";
	private static final String DEFAULT_APP_HOSTNAME = "fibrolamellar.appspot.com";
	private static final String HTML_FORM_OPEN_TAG_PATTERN_STR = "<form[^>]+>";
	private static final Pattern HTML_FORM_OPEN_TAG_PATTERN = Pattern.compile(HTML_FORM_OPEN_TAG_PATTERN_STR);
	private static final String GOOGLE_SIGNED_IN_COOKIE_NAME = "ACSID";
	private static final String AUTOLOGIN_DUMMY_ENDPOINT = "/autologin";
	private static final String GOOGLE_FORM_PASSWORD_INPUT_NAME = "Passwd";
	private static final String GOOGLE_FORM_EMAIL_INPUT_NAME = "Email";
	private static final String VALUE_ATTR = "value";
	private static final String NAME_ATTR = "name";
	private static final String CHARSET_UTF_8 = "UTF-8";
	private static final String APPLICATION_X_WWW_FORM_URLENCODED_CONTENT_TYPE = "application/x-www-form-urlencoded";
	private static final String CONTENT_TYPE_HEADER_NAME = "Content-Type";
	private static final String ACTION_ATTR_PATTERN_STR = "action=\"([^\"]+)\"|action=\'([^\']+)\'";
	private static final String HTML_ATTR_PATTERN_STR = "\\s*(type|name|value|id)\\=(\\'[^\\']*\\'|\\\"[^\\\"]*\\\")\\s*";
	private static final String HTML_INPUT_PATTERN_STR = "<input [^>]+>";
	
	private static final Pattern ACTION_ATTR_PATTERN = Pattern.compile(ACTION_ATTR_PATTERN_STR);	
	private static final Pattern HTML_INPUT_PATTERN = Pattern.compile(HTML_INPUT_PATTERN_STR);
	private static final Pattern HTML_ATTR_PATTERN = Pattern.compile(HTML_ATTR_PATTERN_STR);
	
	private static final String ADMIN_USER_NAME = "johnny.test.appengine@gmail.com";
	private static final String ADMIN_PASSWORD = "testing/1234/";
	
	public static Logger LOGGER = LoggerFactory.getLogger(RemoteAppEngineTester.class);
	
	private String _hostname = DEFAULT_APP_HOSTNAME;
	private String _version = DEFAULT_APP_VERSION;
	private HttpHost _targetHost;
	private DefaultHttpClient _httpClient;
	private BasicHttpContext _localContext;
	private ApacheHttpClient4Executor _executor;

	private static Map<String, TesterParam> paramNameMap = new HashMap<String, TesterParam>();
	
	public enum TesterParam {
		HOSTNAME(new String[]{"h", "host", "hostname"}), 
		VERSION(new String[]{"v", "version"});
			
		private String[] paramNames;
		private TesterParam(String[] theParamNames) {
			for (String paramName : theParamNames) {
				if (paramNameMap.containsKey(paramName)) {
					// should probably be some other exception as this is a compile time error - developer should have known better!
					throw new IllegalArgumentException("Can't use the same parameter name for multiple parameters!");
				}
				paramNameMap.put(paramName, this);
			}				
			paramNames = theParamNames;				
		}
		
		private String[] getAliases() {
			return Arrays.copyOf(paramNames, paramNames.length);
		}
	}
	
	public static void main(String[] args) throws Exception {
		//LOGGER.debug("args: {}", args);
		String hostname = DEFAULT_APP_HOSTNAME;
		String version = DEFAULT_APP_VERSION;

		for (String arg: args) {
			LOGGER.debug("arg: {}", arg);
			String[] argParts = arg.split(":");
			if (argParts == null || argParts.length != 2) {
				LOGGER.debug("Skipping argument {} since it is not formatted properly.", arg);
				continue;
			}
			
			String key = argParts[0];
			String value = argParts[1];
			if (key.startsWith("-")) {
				key = key.substring(1);
			}
			
			TesterParam testerParam = paramNameMap.get(key);
			if (TesterParam.HOSTNAME.equals(testerParam)) {
				hostname = value;
			}
			else if (TesterParam.VERSION.equals(testerParam)) {
				if (!"current".equals(value)) { // need to support a way for tester to specify to test the current version
					version = value;	
				}
				else {
					version = "";
				}
			}
		}
		new RemoteAppEngineTester(hostname, version).signIn(ADMIN_USER_NAME, ADMIN_PASSWORD);
	}
	
	public RemoteAppEngineTester(String anAppHostname, String anAppVersion) throws Exception {
		this._hostname = anAppHostname;
		this._version = anAppVersion;
		
		
		String targetHostURI = Pattern.matches(GOOGLE_APP_ENGINE_VERSION_PATTERN_STR, this._version) ? this._version+"."+this._hostname : this._hostname;
		LOGGER.debug("targetHostURI={}", targetHostURI);
		_targetHost = //new HttpHost("0-7.fibrolamellar.appspot.com"); 
				new HttpHost(targetHostURI);
		_httpClient = new DefaultHttpClient();
		AuthCache authCache = new BasicAuthCache();
		BasicScheme basicAuth = new BasicScheme();
		authCache.put(_targetHost, basicAuth);
		_localContext = new BasicHttpContext();
		_localContext.setAttribute(ClientContext.AUTH_CACHE, authCache);

		_executor = new ApacheHttpClient4Executor(_httpClient, _localContext);
	}    	
	
	public boolean signIn(String aUsername, String aPassword) throws Exception {		
		try {
			LOGGER.info("Before GET request, cookies=");
			TestUtils.printCookies((DefaultHttpClient)_executor.getHttpClient());

			HttpGet getLoginURL = new HttpGet(AUTOLOGIN_DUMMY_ENDPOINT);
			HttpResponse response = _httpClient.execute(_targetHost, getLoginURL, _localContext);

			String googleSigninForm = getGoogleSigninFormFromResponse(response);
			LOGGER.debug("googleSigninForm: {}", googleSigninForm);		
			String action = getPostRequestActionForGoogleSignIn(googleSigninForm);		
			String entityString = getPostEntityFromGoogleSignInForm(googleSigninForm, aUsername, aPassword);
			StringEntity entity = new StringEntity(entityString, CHARSET_UTF_8);
			LOGGER.debug("entity: {}", entityString);

			HttpPost postRequest = new HttpPost(action);
			postRequest.setHeader(CONTENT_TYPE_HEADER_NAME, APPLICATION_X_WWW_FORM_URLENCODED_CONTENT_TYPE);
			postRequest.setEntity(entity);		
			
			LOGGER.debug("post URI: {}", postRequest.getURI());
			response = _httpClient.execute(new HttpHost("accounts.google.com", 443, "https"), postRequest, _localContext);           
			EntityUtils.consume(response.getEntity());

			LOGGER.debug("Am I logged in now?");
			LOGGER.debug("Cookies:");
			TestUtils.printCookies(_httpClient);
			
			HttpGet getRequest = new HttpGet("/hello");
			response = _httpClient.execute(_targetHost, getRequest, _localContext);
			EntityUtils.consume(response.getEntity());
			
			LOGGER.debug("How about now - logged in?");
			TestUtils.printCookies(_httpClient);
			List<Cookie> cookies = _httpClient.getCookieStore().getCookies();
			for (Cookie cookie : cookies) {
				if (GOOGLE_SIGNED_IN_COOKIE_NAME.equals(cookie.getName())) {
					String value = cookie.getValue();
					if (value != null && value.trim().length() > 0) {
						LOGGER.info("Signed into {} using username:{} and password:{}", _targetHost, aUsername, aPassword);
						return true;
					}
				}
			}
			LOGGER.info("Failed to sign in to Google :(");
			return false;
			
		} catch (Exception e) {
			LOGGER.error("caught exception: {}; Tester={}", e, this);
			throw e;
		}
	}

	private static String getPostRequestActionForGoogleSignIn(String aGoogleSignInForm) throws Exception {
		Matcher formTagMatcher = HTML_FORM_OPEN_TAG_PATTERN.matcher(aGoogleSignInForm);
		String formTag = formTagMatcher.find() ? formTagMatcher.group() : "";
		LOGGER.debug("form open tag: {}", formTag);

		// TODO: sometimes there is no form to process - for example, if the site does not require signin
		if ("".equals(formTag)) throw new RuntimeException("error parsing form tag!");

		Matcher actionMatcher = ACTION_ATTR_PATTERN.matcher(formTag);
		String action = actionMatcher.find() ? actionMatcher.group(1) : "";
		LOGGER.debug("action: {}", action);

		return action;
	}

	private static String getPostEntityFromGoogleSignInForm(String aGoogleSignInForm, String aUsername, String aPassword) {
		StringBuilder entitySB = new StringBuilder();
		
		String paramName = "";
		String paramValue = "";
		Matcher inputMatcher = HTML_INPUT_PATTERN.matcher(aGoogleSignInForm);
		
		while (inputMatcher.find()) {
			String anInput = inputMatcher.group();
			Matcher attrMatcher = HTML_ATTR_PATTERN.matcher(anInput);

			while (attrMatcher.find()) {
				String attrName = attrMatcher.group(1);
				String attrValue = attrMatcher.group(2);
				attrValue = attrValue.substring(1, attrValue.length()-1);
				if (NAME_ATTR.equals(attrName)) {
					paramName = attrValue;
				}
				else if (VALUE_ATTR.equals(attrName)) {
					paramValue = attrValue;
				}
			}
			// ASSERT: all attrs for this <input> have been processed; if there is a name-value pair for this <input>, they should be populated in paramName and paramValue
			
			if (!"".equals(paramName)) {				
				if (GOOGLE_FORM_EMAIL_INPUT_NAME.equals(paramName)) paramValue = aUsername; 
				if (GOOGLE_FORM_PASSWORD_INPUT_NAME.equals(paramName)) paramValue = aPassword; 
				entitySB.append(paramName).append("=").append(paramValue).append("&");
				
				// reset values for next HTML input tag
				paramName = paramValue = "";
			}			
		}

		entitySB.setLength(entitySB.length()-1);		// strip off trailing "&"
		return entitySB.toString();
	}
	
	private String getGoogleSigninFormFromResponse(HttpResponse response) throws Exception {
		StringBuilder buffer = new StringBuilder();
		String line = "";
		BufferedReader reader = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
		while ((line = reader.readLine()) != null) {
			buffer.append(line);
		}		
		
		int startIndex = buffer.indexOf("<form");
		if (startIndex >= 0) {
			int endIndex = buffer.indexOf("</form", startIndex);
			if (endIndex > 0) {
				return buffer.substring(startIndex, endIndex);				
			}
		}		
		return "";
	}	
	
	
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(this.getClass().getName());
		sb.append("\n_hostname=").append(this._hostname);
		sb.append("\n_version=").append(this._version);
		sb.append("\n_targetHost=").append(this._targetHost);
		return sb.toString();
	}

}
