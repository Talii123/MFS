package test.friedman.tal;

import java.util.List;

import org.apache.http.cookie.Cookie;
import org.apache.http.impl.client.DefaultHttpClient;

import test.friedman.tal.tester.AppEngineTester;

public class TestUtils {

	public static void printCookies(DefaultHttpClient httpClient) {
		List<Cookie> cookies = httpClient.getCookieStore().getCookies();
		if (cookies.isEmpty()) {
			AppEngineTester.LOGGER.info("None");
		} else {
			for (int i = 0; i < cookies.size(); i++) {
				AppEngineTester.LOGGER.info("- " + cookies.get(i).toString());
			}
		}
	}

}
