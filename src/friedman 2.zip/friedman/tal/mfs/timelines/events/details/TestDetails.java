package friedman.tal.mfs.timelines.events.details;

import java.util.Map;

import javax.jdo.annotations.EmbeddedOnly;
import javax.jdo.annotations.PersistenceCapable;

import friedman.tal.mfs.NotSet;
import friedman.tal.mfs.timelines.events.EventDetails;
import friedman.tal.mfs.timelines.events.details.ChemoDetails.Field;
import friedman.tal.util.Utils;


@PersistenceCapable
@EmbeddedOnly
public class TestDetails extends EventDetails {
	private TestType _testType;

	/*public enum Field {
		oncologist;
	}*/
	
	private TestDetails(Map<String, String> aMap) {		
		// this check cannot be moved to the super class constructor
		if (aMap == null) return;
		
		String value;
		
		value = Utils.getValueOrEmptyString(aMap.get(Field.oncologist.name()));
		//this._oncologist = value.length() > 0 ? value : NotSet.STRING;
	}	
	
	static TestDetails fromMap(Map<String, String> aMap) {
		return new TestDetails(aMap);
	}

}
