package friedman.tal.mfs.timelines.events;

import javax.jdo.annotations.PersistenceCapable;
import javax.jdo.annotations.Persistent;

import friedman.tal.jdo.TypedKey;
import friedman.tal.mfs.timelines.EventJDO;
import friedman.tal.mfs.timelines.EventTO;
import friedman.tal.mfs.timelines.ITimeline;
import friedman.tal.mfs.timelines.events.details.RadiationDetails;

@PersistenceCapable
public class RadiationEventJDO extends EventJDO {

	@Persistent
	private RadiationDetails _eventDetails;
	
	
	RadiationEventJDO(EventTO anEvent, TypedKey<? extends ITimeline, String> aTimelineKey) {
		super(anEvent, aTimelineKey);
		this._eventDetails = (RadiationDetails)anEvent.getTypeDetails();
	}

	
}
