package friedman.tal;

import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.ext.ContextResolver;
import javax.ws.rs.ext.Provider;

import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.DeserializationConfig;

import org.jboss.resteasy.plugins.providers.jackson.ResteasyJacksonProvider;

import friedman.tal.util.SavePropsDeserializationProblemHandler;


// Customized {@code ContextResolver} implementation to pass ObjectMapper to use
@Provider
@Produces(MediaType.APPLICATION_JSON)
public class ConfiguredJacksonProvider extends ResteasyJacksonProvider implements ContextResolver<ObjectMapper> {

	private ObjectMapper objectMapper;

    public ConfiguredJacksonProvider() {
        this.objectMapper = new ObjectMapper().configure(DeserializationConfig.Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        this.objectMapper.getDeserializationConfig().addHandler(new SavePropsDeserializationProblemHandler());
    }
    public ObjectMapper getContext(Class<?> objectType) {
        return objectMapper;
    }
}
