package friedman.tal.mfs.proto;

interface DefaultInter {

	public void publicMethod();
	void defaultMethod();
}
