package friedman.tal;

import java.util.List;

import javax.jdo.PersistenceManager;
import javax.jdo.PersistenceManagerFactory;
import javax.jdo.Query;
import javax.ws.rs.core.SecurityContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;

import friedman.tal.jdo.AbstractJDO;
import friedman.tal.jdo.EntityRef;
import friedman.tal.jdo.IJDO;
import friedman.tal.mfs.proto.QuerySpec;
import friedman.tal.util.PMF;

public abstract class ResourceDAO<T /*extends IJDO<?>*/> {

	protected final Class<T> _theDBClass;
	protected final PersistenceManager _pm;
	protected final SecurityContext _sc;
	
	protected final Logger LOGGER = LoggerFactory.getLogger(this.getClass());
	
	protected ResourceDAO(Class<T> aDBClass, PersistenceManager aPM, SecurityContext anSC) {
		this._theDBClass = aDBClass;
		this._pm = aPM;
		this._sc = anSC;
	}

	@SuppressWarnings("unchecked")
	protected T getResource(Key resourceKey) {		
		try {
			return (T) this._pm.getObjectById(resourceKey);
		} finally {
			this._pm.close();
		}		
	}
	
	protected List<T> findResources(QuerySpec<T> aQuerySpec, Object aQueryValue) {		
		Query query = this._pm.newQuery(this._theDBClass);
//		if (aQuerySpec.hasFilter()) {
//			query.setFilter(aQuerySpec.getFilter());
//		/*
//		 * if the query has a filter, it must have parameters; if it doesn't have a filter, it doesn't need parameters
//		 * }
//		if (aQuerySpec.hasParameters()) {*/
//			query.declareParameters(aQuerySpec.getParameters());
//		}
//		if (aQuerySpec.hasOrdering()) {
//			query.setOrdering(aQuerySpec.getOrdering());
//		}
//		if (aQuerySpec.hasRange()) {
//			query.setRange(aQuerySpec.getRange());
//		}		
		return (List<T>)query.execute(aQueryValue);		
	}
	/*public EntityRef<T> createRef(T entity) {
		return new EntityRef<T>(entity, entity.getKey());
	}	*/	
	
}
