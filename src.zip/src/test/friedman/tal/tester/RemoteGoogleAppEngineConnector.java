package test.friedman.tal.tester;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.http.Header;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.cookie.Cookie;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import test.friedman.tal.TestUtils;

public class RemoteGoogleAppEngineConnector extends AbstractGoogleAppEngineConnector implements IGoogleAppEngineConnector  {
	
	private static final HttpHost GOOGLE_AUTH_HOST = new HttpHost("accounts.google.com", 443, "https");
		
	private static final String GOOGLE_FORM_PASSWORD_INPUT_NAME = "Passwd";
	private static final String GOOGLE_FORM_EMAIL_INPUT_NAME = "Email";
	private static final String GOOGLE_SIGNED_IN_COOKIE_NAME = "ACSID";
	//private static final String AUTOLOGIN_DUMMY_ENDPOINT = "/autologin";
	
	private static final String ADMIN_USER_NAME = "johnny.test.appengine@gmail.com";
	private static final String ADMIN_PASSWORD = "testing/1234/";	
	
	private static final String HTML_FORM_OPEN_TAG_PATTERN_STR = "<form[^>]+>";
	private static final Pattern HTML_FORM_OPEN_TAG_PATTERN = Pattern.compile(HTML_FORM_OPEN_TAG_PATTERN_STR);
	
	private static final String VALUE_ATTR = "value";
	private static final String NAME_ATTR = "name";
	
	private static final String ACTION_ATTR_PATTERN_STR = "action=\"([^\"]+)\"|action=\'([^\']+)\'";
	private static final String HTML_ATTR_PATTERN_STR = "\\s*(type|name|value|id)\\=(\\'[^\\']*\\'|\\\"[^\\\"]*\\\")\\s*";
	private static final String HTML_INPUT_PATTERN_STR = "<input [^>]+>";
	
	
	private static final Pattern ACTION_ATTR_PATTERN = Pattern.compile(ACTION_ATTR_PATTERN_STR);	
	private static final Pattern HTML_INPUT_PATTERN = Pattern.compile(HTML_INPUT_PATTERN_STR);
	private static final Pattern HTML_ATTR_PATTERN = Pattern.compile(HTML_ATTR_PATTERN_STR);

	
	
	public static final Logger LOGGER = LoggerFactory.getLogger(RemoteGoogleAppEngineConnector.class);	
	
	private boolean _isLoggedIn;

	public RemoteGoogleAppEngineConnector(String targetHostURI) {
		super(targetHostURI);
		this._isLoggedIn = false;
	}
	
	@Override
	public final boolean logInAsAdmin() {
		return this.logInAs(ADMIN_USER_NAME, ADMIN_PASSWORD);
	}	
	
	@Override
	public boolean logInAs(String aUsername, String aPassword) {		
		boolean isSignInSuccessful = false;
		try {
			LOGGER.info("Before GET request, cookies=");
			DefaultHttpClient httpClient = this.getHttpClient(); 
			TestUtils.printCookies(httpClient);

			HttpGet getLoginURL = //new HttpGet(AUTOLOGIN_DUMMY_ENDPOINT);
											new HttpGet("/signup");
			HttpResponse response = this.executeRequest(getLoginURL);

			String googleSigninForm = getGoogleSigninFormFromResponse(response);
			LOGGER.debug("googleSigninForm: {}", googleSigninForm);		
			String action = getPostRequestActionForGoogleSignIn(googleSigninForm);		
			String entityString = getPostEntityFromGoogleSignInForm(googleSigninForm, aUsername, aPassword);
			StringEntity entity = new StringEntity(entityString, CHARSET_UTF_8);
			LOGGER.debug("entity: {}", entityString);

			HttpPost postRequest = new HttpPost(action);
			postRequest.setHeader(CONTENT_TYPE_HEADER_NAME, APPLICATION_X_WWW_FORM_URLENCODED_CONTENT_TYPE);
			postRequest.setEntity(entity);		
			
			LOGGER.debug("post URI: {}", postRequest.getURI());
			
			response = this.executeRequest(GOOGLE_AUTH_HOST, postRequest); 
					//_httpClient.execute(GOOGLE_AUTH_HOST, postRequest, _localContext);           			
			EntityUtils.consume(response.getEntity());
		    // do a manual redirect cuz auto-redirect is not working
			LOGGER.debug("\n\n\n all headers: ");
			for (Header header : response.getAllHeaders()) {
				LOGGER.debug("{}", header);
			}
			String locationHeader = response.getFirstHeader("location").getValue();
			LOGGER.debug("\n\n\nlocationHeader: {}", locationHeader);
			if (locationHeader != null && locationHeader.length() > 0) {
				LOGGER.debug("doing manual redirect..");
				HttpGet redirectRequest = new HttpGet(locationHeader);
				response = //_httpClient.execute(GOOGLE_AUTH_HOST, redirectRequest, _localContext);
						this.executeRequest(GOOGLE_AUTH_HOST, redirectRequest);
				EntityUtils.consume(response.getEntity());
			}

			LOGGER.debug("Am I logged in now?");
			LOGGER.debug("Cookies:");
			TestUtils.printCookies(httpClient);
			
			HttpGet getRequest = //new HttpGet("/hello");
											new HttpGet("/signup");
			response = //_httpClient.execute(_targetHost, getRequest, _localContext);
					this.executeRequest(getRequest);
			EntityUtils.consume(response.getEntity());
			
			LOGGER.debug("How about now - logged in?");
			TestUtils.printCookies(httpClient);
			List<Cookie> cookies = httpClient.getCookieStore().getCookies();
			for (Cookie cookie : cookies) {
				if (GOOGLE_SIGNED_IN_COOKIE_NAME.equals(cookie.getName())) {
					String value = cookie.getValue();
					if (value != null && value.trim().length() > 0) {
						LOGGER.info("Signed into {} using username:{} and password:{}", this.getTargetHost(), aUsername, aPassword);
						this._isLoggedIn = isSignInSuccessful = true;
					}
				}
			}
			
			if (!isSignInSuccessful) {
				LOGGER.info("Failed to sign in to Google :(");				
			}
			
			return isSignInSuccessful;
			
		} catch (Exception e) {
			LOGGER.error("caught exception: {}; Tester={}; \n stackTrace = {}", e, this, e.getStackTrace());
			
			return isSignInSuccessful;
		} 
	}

	@Override
	public boolean isLoggedIn() {
		return this._isLoggedIn;
	}


	private static String getPostRequestActionForGoogleSignIn(String aGoogleSignInForm) throws Exception {
		Matcher formTagMatcher = HTML_FORM_OPEN_TAG_PATTERN.matcher(aGoogleSignInForm);
		String formTag = formTagMatcher.find() ? formTagMatcher.group() : "";
		LOGGER.debug("form open tag: {}", formTag);

		// TODO: sometimes there is no form to process - for example, if the site does not require signin
		if ("".equals(formTag)) throw new RuntimeException("no form tag to parse!");

		Matcher actionMatcher = ACTION_ATTR_PATTERN.matcher(formTag);
		String action = actionMatcher.find() ? actionMatcher.group(1) : "";
		LOGGER.debug("action: {}", action);

		return action;
	}

	private static String getPostEntityFromGoogleSignInForm(String aGoogleSignInForm, String aUsername, String aPassword) {
		StringBuilder entitySB = new StringBuilder();
		
		String paramName = "";
		String paramValue = "";
		Matcher inputMatcher = HTML_INPUT_PATTERN.matcher(aGoogleSignInForm);
		
		while (inputMatcher.find()) {
			String anInput = inputMatcher.group();
			Matcher attrMatcher = HTML_ATTR_PATTERN.matcher(anInput);

			while (attrMatcher.find()) {
				String attrName = attrMatcher.group(1);
				String attrValue = attrMatcher.group(2);
				attrValue = attrValue.substring(1, attrValue.length()-1);
				if (NAME_ATTR.equals(attrName)) {
					paramName = attrValue;
				}
				else if (VALUE_ATTR.equals(attrName)) {
					paramValue = attrValue;
				}
			}
			// ASSERT: all attrs for this <input> have been processed; if there is a name-value pair for this <input>, they should be populated in paramName and paramValue
			
			if (!"".equals(paramName)) {				
				if (GOOGLE_FORM_EMAIL_INPUT_NAME.equals(paramName)) paramValue = aUsername; 
				if (GOOGLE_FORM_PASSWORD_INPUT_NAME.equals(paramName)) paramValue = aPassword; 
				entitySB.append(paramName).append("=").append(paramValue).append("&");
				
				// reset values for next HTML input tag
				paramName = paramValue = "";
			}			
		}

		entitySB.setLength(entitySB.length()-1);		// strip off trailing "&"
		return entitySB.toString();
	}
	
	private String getGoogleSigninFormFromResponse(HttpResponse response) throws Exception {
		StringBuilder buffer = new StringBuilder();
		String line = "";
		BufferedReader reader = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
		while ((line = reader.readLine()) != null) {
			buffer.append(line);
		}		
		
		int startIndex = buffer.indexOf("<form");
		if (startIndex >= 0) {
			int endIndex = buffer.indexOf("</form", startIndex);
			if (endIndex > 0) {
				return buffer.substring(startIndex, endIndex);				
			}
		}		
		return "";
	}	

}
