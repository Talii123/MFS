package friedman.tal.resources;

public interface IProtectableResource {

}
