package friedman.tal.mfs.timelines.events.details;

public enum CancerStage {
	UNKNOWN, I, II, III, IV;
}
