package friedman.tal.util;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;


public class Utils {
	public static final String DEFAULT_ERROR_STRING = "String is invalid because: %s";
	
	public static final String HTML_FORM_MEDIATYPE = "application/x-www-form-urlencoded";
	
	public static <E> List<E> newList() {
		return new ArrayList<E>();
	}
	
	public static <K, V> Map<K, V> newMap() {
		return new HashMap<K, V>();
	}
	
	public static <E> Set<E> newSet() {
		return new HashSet<E>();
	}
	
	public static <E> SortedSet<E> newSortedSet() {
		return new TreeSet<E>();
	}
	
	
	public static void read(InputStream in) {
		read(new InputStreamReader(in));
	}

	public static void read(Reader aReader) {
		BufferedReader reader = new BufferedReader(aReader);
		try {
			String line;
			while ((line = reader.readLine()) != null) {
				System.out.println(line);
			}			
			reader.close();
		} catch (Exception e) {
			e.printStackTrace(System.err);
		}
	}

	
}
