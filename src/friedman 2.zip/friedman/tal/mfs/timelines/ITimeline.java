package friedman.tal.mfs.timelines;

import friedman.tal.resources.IProtectableResource;

public interface ITimeline extends IProtectableResource {

	public void addEvent(EventJDO anEvent);

}
