package friedman.tal.mfs.timelines.events.details;

import java.util.Map;

import javax.jdo.annotations.EmbeddedOnly;
import javax.jdo.annotations.NotPersistent;
import javax.jdo.annotations.PersistenceCapable;
import javax.jdo.annotations.Persistent;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import friedman.tal.mfs.NotSet;
import friedman.tal.mfs.timelines.events.EventDetails;
import friedman.tal.util.Utils;

@PersistenceCapable
@EmbeddedOnly
public class DiagnosisDetails extends EventDetails {
	// cannot make @Persistent fields 'final', so enforce immutability as best we can using no setters and private fields
	
	@NotPersistent
	private static Logger LOGGER = LoggerFactory.getLogger(DiagnosisDetails.class);
	
	@Persistent
	private Byte _age;
	
	@Persistent
	private CancerStage _stage;
	
	@Persistent
	private Boolean _isMetastatic;
	
	@Persistent
	private Boolean _isLymphNodeInvolvement;
	
	@Persistent
	private Boolean _isMajorVascularInvasion;
	
	@Persistent
	private Boolean _isMicroVascularInvasion;
	
	public enum Field {
		age,
		stage,
		metastatic,
		lymphNodes,
		majorVascularInvasion,
		microVascularInvastion
		/*age("age"),
		stage("stage"),
		isMetastatic("metastatic"),
		isLymphNodeInvolvement("lymphNodeInvolvement"),
		majorVascularInvasion("majorVascularInvasion"),
		microVascularInvasion("minorVascularInvasion");
		
		private final String paramName;
		
		private Field(String aParamName) {
			this.paramName = aParamName;
		}
		
		public String getParamName() {
			return this.paramName;
		}
		
		public static Field valueByParamName(String aParamName) {
			return mapping.get(aParamName);
		}
		
		private static final Map<String, Field> mapping;
		static {
			mapping = Utils.newMap();
			for (Field field : Field.values()) {
				mapping.put(field.getParamName(), field);
			}
		}*/
	}
	
	private DiagnosisDetails(Map<String, String> aMap) {
		LOGGER.debug("aMap: {}", aMap);
		
		// this check cannot be moved to the super class constructor
		if (aMap == null) return;
		
		String value;
		
		// note: if the field is not specified it is set to null; we're using object type wrappers for primitives 
		// so that we can have nillable fields;  We don't want to store "false" for fields the user does not specify
		value = Utils.getValueOrEmptyString(aMap.get(Field.age.name()));
		this._age = value.length() > 0 ? Byte.valueOf(value) : NotSet.BYTE;	
		
		value = Utils.getValueOrEmptyString(aMap.get(Field.stage.name()));
		this._stage = value.length() > 0 ? CancerStage.valueOf(value) : NotSet.CANCER_STAGE;	
		
		value = Utils.getValueOrEmptyString(aMap.get(Field.metastatic.name()));
		this._isMetastatic = value.length() > 0 ? Boolean.valueOf(value) : NotSet.BOOLEAN;
		
		value = Utils.getValueOrEmptyString(aMap.get(Field.lymphNodes.name()));
		this._isLymphNodeInvolvement = value.length() > 0 ? Boolean.valueOf(value) : NotSet.BOOLEAN;
		
		value = Utils.getValueOrEmptyString(aMap.get(Field.majorVascularInvasion.name()));
		this._isMajorVascularInvasion = value.length() > 0 ? Boolean.valueOf(value) : NotSet.BOOLEAN;
		
		value = Utils.getValueOrEmptyString(aMap.get(Field.microVascularInvastion.name()));
		this._isMicroVascularInvasion = value.length() > 0 ? Boolean.valueOf(value) : NotSet.BOOLEAN;
	}
	
	static DiagnosisDetails fromMap(Map<String, String> aMap) {
		return new DiagnosisDetails(aMap);
	}
	
	
	public Byte getAge() {
		return this._age;
	}
		
	
	public CancerStage getStage() {
		return this._stage;
	}
	
	public Boolean isMetastatic() {
		return this._isMetastatic;
	}
	
	public void setLymphNodeInvolvement(boolean isLymphNodeInvolvement) {
		this._isLymphNodeInvolvement = isLymphNodeInvolvement;
	}

	public Boolean isLymphNodeInvolvement() {
		return this._isLymphNodeInvolvement;
	}	

	public Boolean isMajorVascularInvasion() {
		return this._isMajorVascularInvasion;
	}

	public Boolean isMicroVascularInvasion() {
		return this._isMicroVascularInvasion;
	}
	
	
/*
 * make this read-only
 * 
	public void setMicroVascularInvasion(boolean isMicroVascularInvasion) {
		this._isMicroVascularInvasion = isMicroVascularInvasion;
	}
	
	public void setAge(byte anAge) {
		this._age = anAge;
	}

	public void setStage(CancerStage aCancerStage) {
		this._stage = aCancerStage;
	}

	public void setMetastatic(boolean isMetastatic) {
		this._isMetastatic = isMetastatic;
	}
	
	public void setMajorVascularInvasion(boolean majorVascularInvasion) {
		this._isMajorVascularInvasion = majorVascularInvasion;
	}

*/	

}
