package friedman.tal.mfs.timelines.events;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import friedman.tal.jdo.TypedKey;
import friedman.tal.mfs.timelines.EventJDO;
import friedman.tal.mfs.timelines.EventTO;
import friedman.tal.mfs.timelines.ITimeline;


public class EventJDOFactory {
	private static final Logger LOGGER = LoggerFactory.getLogger(EventJDOFactory.class);

	public static EventJDO createEvent(EventTO anEventTO, TypedKey<? extends ITimeline, String> aTimelineKey) {
		EventJDO eventJDO;
		EventType eventType = anEventTO.getType(); 
		switch (eventType) {
		case CHAPTER:
			eventJDO = new ChapterEventJDO(anEventTO, aTimelineKey);
			break;
			
		case DIAGNOSIS:
			eventJDO = new DiagnosisEventJDO(anEventTO, aTimelineKey);
			break;

		case SURGERY: 
			eventJDO = new SurgeryEventJDO(anEventTO, aTimelineKey);
			break;
			
		case CHEMO:
			eventJDO = new ChemoEventJDO(anEventTO, aTimelineKey);
			break;
			
		case RADIATION:
			eventJDO = new RadiationEventJDO(anEventTO, aTimelineKey);
			break;
			
		case IMMUNO:
			eventJDO = new ImmunoEventJDO(anEventTO, aTimelineKey);
			break;
			
		case TEST:
			eventJDO = new TestEventJDO(anEventTO, aTimelineKey);
			break;
		default:
			LOGGER.error("Unrecognized Event type: {}; cannot create an EventJDO object.", eventType);
			throw new IllegalArgumentException(String.format("Unrecognized Event type: %s; cannot create an EventJDO object.", eventType));
		}
		
		return eventJDO;
	}	

}
