package friedman.tal.mfs.users;

import java.util.List;

import javax.jdo.annotations.PersistenceCapable;
import javax.jdo.annotations.Persistent;
import javax.jdo.annotations.PrimaryKey;

import friedman.tal.jdo.IJDO;
import friedman.tal.mfs.agreements.IAgreement;
import friedman.tal.mfs.timelines.ITimeline;
import friedman.tal.util.Utils;

//TODO: write unit tests for equals() and hashcode()
//TODO: validate inputs to constructor?

@PersistenceCapable
public class UserAccountJDO implements IUserAccount {

	@PrimaryKey
	private String _name;
	
	@Persistent
	private ITimeline _timeline;
	
	@Persistent(mappedBy = "_agreer")
	private List<IAgreement> _agreements;
	
	public UserAccountJDO(String anEmail) {
		this._name = anEmail;
		this._agreements = Utils.newList();
	}
	
	public UserAccountJDO(String anEmail, ITimeline aTimeline) {
		this(anEmail);
		this._timeline = aTimeline;
	}

	@Override
	public boolean equals(Object other) {
		if (this == other) return true;
		if (!(other instanceof IUserAccount)) return false;
		IUserAccount otherUserAccount = (IUserAccount)other;
		// agreements should not be part of equals method - should be able to distinguish user by identity
		
		// loading timeline may be an expensive operation so do it only once
		ITimeline otherTimeline = otherUserAccount.getTimeline();
		return this._name.equals(otherUserAccount.getName()) &&
					(this._timeline == otherTimeline || (this._timeline != null && this._timeline.equals(otherTimeline)));
	}

	
	@Override
	public int hashCode() {
		int result = 17;
		result = 31 * result + this._name.hashCode();
		result = 31 * result + this._timeline.hashCode();
		return result;
	}

	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(IJDO.JDO_STR_START_TOKEN).append(this.getClass()).append(": ")
			//.append("_id=").append(_id).append(", ")
			.append("_name=").append(_name).append(IJDO.JDO_PROPERTY_DELIMITER)
			.append("_timeline=").append(_timeline).append(IJDO.JDO_PROPERTY_DELIMITER)
			.append(IJDO.JDO_STR_END_TOKEN);
				
		return sb.toString();
	}

	@Override
	public void addAgreement(IAgreement anAgreement) {
		this._agreements.add(anAgreement);
	}

	@Override
	public String getName() {
		return _name;
	}

	@Override
	public ITimeline getTimeline() {
		return _timeline;
	}

	@Override
	public void setTimeline(ITimeline timeline) {
		this._timeline = timeline;
	}
	
}
